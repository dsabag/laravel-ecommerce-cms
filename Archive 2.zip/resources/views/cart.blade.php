@extends('master')
@section('main_content')
<section class="breadcumb-area jarallax bg-img af">
    <div class="breadcumb">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="content">
                        <h2>Checkout</h2>
                      @component('components.url_link')
                          @slot('home')Home
                          @endslot
                          @slot('page_name')Cart
                          @endslot
                      @endcomponent
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="row">
<div class="col-lg-12">
    <br><br><br>
        <div class="section-heading">
                <h2>Shopping Cart</h2>
            </div>

            <div class="container mycont">

                @if (!Cart::isEmpty())

<table class="table table-bordered table-responsive-sm">

    <thead>
        <tr>
            <th>Product</th>
            <th class="text-center">Quantity</th>
            <th>Price</th>
            <th>Sub Total</th>
            <th></th>
        </tr>
    </thead>
<tbody>
@foreach ($cart as $item)

<tr>
<td>{{ $item['name'] }}</td>
<td class="text-center">

<button data-pid="{{ $item['id'] }}" data-op="minus" type="button" class="minus-plus update-cart-btn btn btn-primary btn-sm">
                <i class="fas fa-minus-circle minus"></i>
        </button>

<input size="2" class="text-center" type="text" value="{{ $item['quantity'] }}" id=""> 

<button data-pid="{{ $item['id']}}" data-op="plus"  type="button" class="minus-plus update-cart-btn btn btn-primary btn-sm">

        <i class="fas fa-plus-circle"></i>

</button>
</td>
<td>${{ $item['price'] }}</td>
<td>${{ $item['quantity']*$item['price']}}</td>
<td class="text-center">

<button data-pid="{{ $item['id'] }}" class="btn btn-sm btn-danger remove-from-cart-btn"><i class="fas fa-trash-alt"></i></button>

</td>
</tr>
@endforeach

</tbody>
</table>

<p>
<b>Total In Cart: </b> ${{ Cart::getTotal() }}
<span class="clear-cart">
<a href="" class="btn btn-light clear-cart-btn">Clear Cart</a>
</span>
</p>
<p>

<a href="{{ url('shop/checkout') }}" class="btn4 btn-lg">Buy Now</a>

</p>
@else

<div class="col-12 text-center"><b>Cart Is Empty</b></div>

@endif


</div>
</div>
</div>


@endsection