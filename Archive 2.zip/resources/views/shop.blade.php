@extends('master')
@section('main_content')

  <!--Breadcumb area start here-->
  <section class="breadcumb-area jarallax bg-img af">
    <div class="breadcumb">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="content">
                        <h2>Categories</h2>
                        @component('components.url_link')
                        @slot('home')Home
                        @endslot
                        @slot('page_name')Categories
                        @endslot
                    @endcomponent
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Breadcumb area end here-->

<!-- categories start here -->
<section class="shop-page section bg-img jarallax">
    <div class="container">
<div class="row">
    <div class="col-md-12 col-sm-12 pd-0">
        <div class="pro-sliders">
           @foreach ($categories as $categorie)
           <div class="col-sm-12">
            <div class="products">
            <figure><img height="250" src="{{ asset('images/'.$categorie->image) }} "alt="" /></figure>
                <div class="contents">
                <h3>{{ $categorie->title }}</h3>
                    <br>
                    <a href="{{ url('shop/'.$categorie->url) }}" class="btn4">View Products</a>
                </div>
            </div>
        </div>
               
           @endforeach
</div>
</div>
</div>
</div>

</section>
<!--categories area end here-->

@endsection