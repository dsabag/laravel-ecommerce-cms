@extends('cms.cms_master')
@section('cms_content')
   
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->

   

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        @component('components.cms_components')
        @slot('title')Orders
        @endslot
        @endcomponent
    
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-12">
        <div class="card shadow mb-4 text-center">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Completed Orders</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                  
                   <th>User</th>
                   <th>Total</th>
                   <th>Order Details</th>
                   <th>Order Date</th>
                   
                    </tr>
                  </thead>
                
                  <tbody>
                 @foreach($orders as $order)
                <tr>
                  <td>{{$order->email}}</td>
                  <td>${{$order->total}}</td>
                  <td>
                <ul>
                @foreach (unserialize($order->data) as $item)
                    
                <li>

                    <b>{{ $item['name'] }} </b> 
                    <b>Price: </b>${{ $item['price'] }}
                    <b>Quantity: </b>{{ $item['quantity'] }}
            
                    
                </li>

                @endforeach

                </ul>
                  </td>
                  <td>{{date('d/m/Y H:i:s',strtotime($order->created_at))}}</td>
                </tr>
                 @endforeach
             
                  </tbody>
                </table>
                <div class="row mb-5">
                  <div class="col-12">
                     {{ $orders->links() }}

                 </div>

                </div>
                
              </div>
            </div>
        </div>
          </div>


  </div>
</div>
  <!-- /.container-fluid -->




@endsection
