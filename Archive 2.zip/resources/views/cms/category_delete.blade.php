@extends('cms.cms_master')
@section('cms_content')
   
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->

   

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        @component('components.cms_components')
        @slot('title')Category
        @endslot
        @endcomponent

    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Are You Sure You Want To Delete This Category?</h6>
            </div>
            <div class="card-body">
            <form action="{{ url('cms/categories/'.$item_id)}}" method="POST" autocomplete="off" novalidate="novalidate" class="my-form">
                  @csrf
                {{ method_field('DELETE')}}
            <button type="submit" class="btn btn-danger mr-3" name="submit">Delete</button>
            <a href="{{ url('cms/categories') }}" type="button" class="btn btn-light">Cancel</a>

              </form>
            </div>
        </div>
          </div>


  </div>
  <!-- /.container-fluid -->
</div>




@endsection
