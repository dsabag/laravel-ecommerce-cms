@extends('cms.cms_master')
@section('cms_content')
   
   <!-- Begin Page Content -->
   <div class="container-fluid mb-5">

    <!-- Page Heading -->

   

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        @component('components.cms_components')
        @slot('title')Add New Content
        @endslot
        @endcomponent

    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Set Up Your Content</h6>
            </div>
            <div class="card-body">
            <form id="add-content-form" action="{{ url('cms/content') }}" method="POST" autocomplete="off" novalidate="novalidate" class="my-form">
                  @csrf
                  <div class="form-group">
                    <label for="menu_id">* Menu Link</label>
                    <select class="form-control" name="menu" id="menu">
                    <option value="">Choose Menu Link...</option>
                    @foreach($menu as $menu_item)
                    <option @if( old('menu') == $menu_item->id ) selected="selected"
                        @endif
                         value="{{ $menu_item->id }}">{{ $menu_item->link }}</option>
                    @endforeach
                    </select>
                    <span class="text-danger">{{ $errors->first('menu') }}</span>
                </div>
<div class="form-group">
    <label for="title">* Content Title</label>
    <input value="{{ old('title') }}" type="text" name="title" id="title" class="form-control">
    <span class="text-danger">{{ $errors->first('title') }}</span>
</div>
<div class="form-group">
    <label for="title">* Content Article</label>
<textarea class="form-control article" name="article" cols="30" rows="10">{{ old('article') }}</textarea>
    <span class="text-danger">{{ $errors->first('article') }}</span>
</div>
<div class="form-group">
<button type="submit" class="btn btn-success mr-3" name="submit">Save</button>
<a href="{{ url('cms/content') }}" type="button" class="btn btn-light">Cancel</a>
</div>
              </form>
            </div>
        </div>
          </div>
  </div>
  <!-- /.container-fluid -->
</div>


@endsection
