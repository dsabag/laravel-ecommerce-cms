
@extends('cms.cms_master')
@section('cms_content')
   
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->

   

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        @component('components.cms_components')
        @slot('title')Products
        @endslot
        @endcomponent
    <a href="{{ url('cms/products/create') }}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Add A New Product</a>
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-12">
        <div class="card shadow mb-4 text-center">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Current Products</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th><b>Product Title</b></th>
                      <th><b>Price</b></th>
                      <th><b>Product Image</b></th>
                      <th><b>Category</b></th>
                      <th><b>Last Update</b></th>
                      <th></th>
                    
                    </tr>
                  </thead>
                
                  <tbody>
                 @foreach($product_category as $item)

                 <tr>
                 <td>{{ $item->ptitle }}</td>
                 <td>{{ $item->price }}$</td>
                 <td><img class="" height="80" width="120" src="{{ asset('images/'. $item->pimage) }}"></td>
                 <td>{{ $item->url }}</td>
                 <td>{{ date('d/m/Y', strtotime($item->updated_at))}}</td>
                 <td style="white-space: nowrap"> <a href="{{ url('cms/products/'. $item->id. '/edit') }}" title="Edit Menu" class="btn btn-info btn-circle btn-sm">
                  <i class="far fa-edit"></i>
                 </a> <a href="{{ url('cms/products/'. $item->id) }}" title="Delete Menu"  class="btn btn-danger btn-circle btn-sm ml-3">
                    <i class="fas fa-trash"></i>
                  </a></td>

                 </tr>

                 @endforeach
             
                  </tbody>
                </table>
                <div class="row mb-5">
                  <div class="col-12">
                     {{ $product_category->links() }}

                 </div>

                </div>
                
              </div>
            </div>
        </div>
          </div>


  </div>
</div>
  <!-- /.container-fluid -->




@endsection
