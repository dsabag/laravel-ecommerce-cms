@extends('cms.cms_master')
@section('cms_content')
   
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->

   

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        @component('components.cms_components')
        @slot('title')Messages
        @endslot
        @endcomponent
    
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-12">
        <div class="card shadow mb-4 text-center">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">User Messages</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                  
                   <th>User</th>
                   <th>Reply Email</th>
                   <th>Subject</th>
                   <th>Message</th>
                   <th>Date</th>
                   
                    </tr>
                  </thead>
                
                  <tbody>
                 @foreach($contacts as $contact)
                <tr>
                  <td>{{$contact->email}}</td>
                  <td>{{$contact->cemail}}</td>
                  <td>{{$contact->subject}}</td>
                  <td>{{$contact->message}}</td>               
                  <td>{{date('d/m/Y H:i:s',strtotime($contact->created_at))}}</td>
                </tr>
                 @endforeach
             
                  </tbody>
                </table>
                <div class="row mb-5">
                  <div class="col-12">
                     {{ $contacts->links() }}

                 </div>

                </div>
                
              </div>
            </div>
        </div>
          </div>


  </div>
</div>
  <!-- /.container-fluid -->




@endsection
