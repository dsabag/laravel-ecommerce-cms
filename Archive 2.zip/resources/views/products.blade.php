@extends('master')
@section('main_content')

  <!--Breadcumb area start here-->
  <section class="breadcumb-area jarallax bg-img af">
    <div class="breadcumb">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="content">
                    <h2>{{$categorie_name[0]->title }}</h2>
                    @component('components.url_link')
                    @slot('home')Home
                    @endslot
                    @slot('page_name'){{$categorie_name[0]->title }}
                    @endslot
                @endcomponent
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Breadcumb area end here-->
<!--Products area start here-->
<section class="shop-page section">
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="sibebar">
                   
                    <div class="wighet categories">
                        <h3>categ<span>ories</span></h3>
                        <ul>
                           @foreach ($categories as $categorie)
                        <li><a href="{{ $categorie->url }}"><i class="fa fa-angle-double-right"></i>{{ $categorie->title }}<span>{{ $inventory[$counter]->list }}</span></a></li>
                        @php
                            $counter++;
                        @endphp
                        
                           @endforeach

                          
                        </ul>
                    </div>
                  
                </div>
            </div>
            <div class="col-sm-9 pd-0">
                <div class="col-sm-12">
                    <div class="filter-area">
                      
                        <div class="list-grid">
                            <ul class="list-inline">
                                <li><a href="#" id="gridview"><i class="fa fa-th"></i></a></li>
                                <li><a href="#" id="listview"><i class="fa fa-list"></i></a></li>
                            </ul>
                        </div>
                        <div class="showpro">
                            
                            <p><span>Showing {{ $products->firstItem() }}-{{ $products->lastItem() }}</span> of {{ $products->total() }} Results</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 pd-0">
                   @foreach ($products as $product)
                   <div class="col-sm-4 products">
                   <figure><img height="180" src="{{ asset('images/'.$product->pimage) }}" alt="" /></figure>
                    <div class="contents">
                        <h3>{{ $product->ptitle }}</h3>
                    <p>{{ $product->particle }}</p>
                    <span>${{ $product->price }}</span>
                    @if (!Cart::get($product->id))
                    <button data-pid="{{ $product->id }}" class="btn1 add-to-cart-btn"><i class="fas fa-cart-plus"></i>  Add To Cart</button>

                    @else
                    <button data-pid="{{ $product->id }}" class="btn1 btn-success add-to-cart-btn" disabled="disabled"><i class="fas fa-thumbs-up"></i> Item In Cart</button>

                    @endif
                 <br><br>
                    <a href="{{ url('shop/'.$product->url.'/' .$product->purl) }}" class="btn4"><i class="fas fa-eye"></i> More Details</a>
                    </div>
                </div>
                   @endforeach
                
               
            </div>
        </div>
    </div>

    <div class="col-sm-12">
        <div class="paginations">
            <ul>
                <li> {{ $products->links() }} </li>
             
            </ul>
        </div>
    </div>
</section>
<!--Products area end here-->

@endsection