<ul>
    <li><a href="{{ url('') }}">{{$home}}</a></li>
    <li><a href="javascript:void(0)">{{$page_name}}</a></li>
</ul>
