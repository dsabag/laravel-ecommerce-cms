@extends('master')
@section('main_content')

 <!--Breadcumb area start here-->
 <section class="breadcumb-area jarallax bg-img af">
    <div class="breadcumb">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="content">
                    <h2>{{ $contents[0]->title }}</h2>
                        @component('components.url_link')
                        @slot('home')Home
                        @endslot
                        @slot('page_name'){{ $contents[0]->title }}
                        @endslot
                    @endcomponent
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Breadcumb area end here-->
   <!--About area start here-->
   <section class="about-area section bg-img mycont-2">
      
    <div class="container">
        @foreach ($contents as $content)
       
        <div class="row">
            <div class="col-md-7 col-sm-12">
                <div class="section-heading2">
                <h2>{{ $content->ctitle }}</h2>
                </div>
                <div class="about-contents">
                <p>{!! $content->carticle !!}</p>
                
                </div>
            </div>
        
        </div>
        <br><br><br>
        @endforeach
    </div>
</section>
<!--About area end here-->


@endsection