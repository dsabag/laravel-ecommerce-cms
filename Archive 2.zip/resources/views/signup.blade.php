@extends('master')

@section('main_content')
    
    <!--Breadcumb area start here-->
    <section class="breadcumb-area jarallax bg-img af">
            <div class="breadcumb">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="content">
                                <h2>Contact us</h2>
                                @component('components.url_link')
                                @slot('home')Home
                                @endslot
                                @slot('page_name')Sign Up
                                @endslot
                            @endcomponent
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <!--Breadcumb area end here-->
    <!--register area start here-->
 <!-- login_form_wrapper -->
 <br><br><br><br>
 <div class="">
     <div class="container">
         <div class="row">
             <div class="col-md-12 col-sm-12">
                 <div class="section-heading">
                     <h2>Sign Up a New Account</h2>
                     <p>please Sign Up To Order From Our Shop</p>
                 </div>
             </div>
         </div>
         <div class="row">
                <div class="col-md-8 col-md-offset-2">
                        <div class="register_wrapper_box">
                            <div class="register_left_form">
    
                                <div class="jp_regiter_top_heading">
                                    <p>Fields with * are mandetory </p>
                                </div>
                                <form action="" method="POST" novalidate="novalidate" autocomplete="off">
                                <div class="row clearfix">
                                    @csrf
                                    <!--Form Group-->
                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <label for="name" class="d-block"></label>
                                        <input type="text" name="name" id="name" placeholder="Username*">
                                    <span class="text-danger">{{ $errors->first('name') }}</span>
                                    </div>
                                    <!--Form Group-->
                                    <label for="email" class="d-block"></label>
                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <input type="email" name="email" id="email"
                                        placeholder="Email*">
                                        <span class="text-danger">{{ $errors->first('email') }}</span>
                                    </div>
                                    <!--Form Group-->
                                    <label for="password" class="d-block"></label>
                                    <div class="form-group col-xs-12">
                                        <input type="password" name="password" id="password"
                                        placeholder="password*">
                                        <span class="text-danger">{{ $errors->first('password') }}</span>
                                    </div>
 
                        
                                </div>
    
                                <div class="login_btn_wrapper register_btn_wrapper login_wrapper register_wrapper_btn">
                                    <button type="submit" class="btn btn-primary my-login_btn"> Sign Up </button>
                                </div>

                            </form>

                                <div class="login_message">
                                    <p>Already a member? <a href="{{ url('user/signin') }}"> Sign In Here </a> </p>
                                </div>
    
                            </div>
    
                        </div>
                        <p class="btm_txt_register_form">In case you are using a public/shared computer we recommend that
                            you logout to prevent any un-authorized access to your account</p>
                    </div>
         </div>
     </div>
 </div>
 <!-- /.login_form_wrapper-->
    <!--register area start end-->

@endsection
    
