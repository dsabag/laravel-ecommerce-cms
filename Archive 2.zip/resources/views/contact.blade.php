@extends('master')
@section('main_content')
  <!--Breadcumb area start here-->
  <section class="breadcumb-area jarallax bg-img af">
    <div class="breadcumb">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="content">
                        <h2>Contact us</h2>
                        @component('components.url_link')
                        @slot('home')Home
                        @endslot
                        @slot('page_name')Contact Us
                        @endslot
                    @endcomponent
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Breadcumb area end here-->
<!--Contact area start here-->
<br><br><br><br>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="section-heading">
        <h2>Get in touch</h2>
        <p>Our Customer Service Agents Are Available 24/7, Please Feel Free To Contact Us At All Times</p>
    </div>
</div>
<br><br><br>
<section class="contact-area section">
    <div class="container">
        <div class="row mr-b50">
            <div class="col-lg-4 col-md-12 col-xs-12 col-sm-12">
                <div class="contact-info">
                    <span><i class="fa fa-map-marker"></i></span>
                    <p>Zeev Liber St,
                        <br> Netanya, Israel</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-12 col-xs-12 col-sm-12">
                <div class="contact-info">
                    <span><i class="fa fa-phone"></i></span>
                    <p>09-8993877</p>
                    <p>050-7728899</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-12 col-xs-12 col-sm-12">
                <div class="contact-info">
                    <span><i class="fa fa-envelope"></i></span>
                    <p>dsabag85@gmail.com</p>
                </div>
            </div>
        </div>
        <div class="row">
            
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-area">
                    <form action="" method="POST" novalidate="novalidate" autocomplete="off">
                        @csrf
                        <fieldset>
                            <div class="row">
                                <div class="col-sm-4 col-xs-12 feld">
                                    <input type="text" placeholder="Full Name *" name="name" id="name">
                                    <span><i class="fa fa-user"></i></span>
                                    <div class="text-danger">{{ $errors->first('name') }}</div>
                                    
                                </div>
                                <div class="col-sm-4 col-xs-12 feld">
                                    <input type="email" placeholder="Email *" name="email" id="email">
                                    <span><i class="fa fa-envelope"></i></span>
                                    <div class="text-danger">{{ $errors->first('email') }}</div>
                                </div>
                                <div class="col-sm-4 col-xs-12 feld">
                                    <input type="text" placeholder="Subject *" name="subject" id="subject">
                                    <span><i class="fa fa-star"></i></span>
                                    <div class="text-danger">{{ $errors->first('subject') }}</div>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <div class="feld">
                                <textarea placeholder="Message *" name="message" id="message"></textarea>
                                <span class="msg"><i class="fa fa-pencil-square-o"></i></span>
                                <div class="text-danger">{{ $errors->first('message') }}</div>
                            </div>
                        </fieldset>
                        <div class="btn-area text-center">
                            <button type="submit" class="btn1"><span>Send now</span></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Contact area end here-->

@endsection