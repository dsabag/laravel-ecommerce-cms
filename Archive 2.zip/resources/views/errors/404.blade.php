@php

$menu = App\Menu::all();
$page_title = 'Page Not Found';
$categories = App\Categorie::all();

@endphp
@extends('master')
@section('main_content')
<section class="breadcumb-area jarallax bg-img af">
    <div class="breadcumb">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="content">
                        <h2>404 - Page Not Found</h2>
                      @component('components.url_link')
                          @slot('home')
                          @endslot
                          @slot('page_name')
                          @endslot
                      @endcomponent
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="about-area section bg-img jarallax">
      
        <div class="container">
            <div class="row">
                <div class="col-md-7 col-sm-12">
                    <div class="section-heading2">
                    <h2>This Page Has Been Shot... <a href="{{ url('') }}">Go Home</a></h2>
                    </div>
                    
                </div>
                
            </div>
        </div>
    </section>

@endsection