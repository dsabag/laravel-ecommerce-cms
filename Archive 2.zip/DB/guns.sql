-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Sep 25, 2020 at 10:36 PM
-- Server version: 5.7.26
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `guns`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `image`, `url`, `icon`, `updated_at`, `created_at`) VALUES
(1, 'Assault Rifles', '2020.09.14.19.17.24-r6lOr -assault.jpg', 'assault-rifles', '3.png', '2020-09-14 19:17:24', '2020-06-27 00:00:00'),
(4, 'Handguns', '2020.09.14.19.17.46-936Sm -hand.jpeg', 'handguns', '1.png', '2020-09-14 19:17:46', '2020-06-27 00:00:00'),
(6, 'Sniper Rifles', '2020.09.14.19.17.55-LT2rt -sniper.jpg', 'sniper-rifles', '03.png', '2020-09-14 19:17:55', '2020-06-27 00:00:00'),
(7, 'Attachments', '2020.09.14.19.18.06-Y9eQ9 -attachments.jpg', 'attachments', '4.png', '2020-09-14 19:18:06', '2020-07-11 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `cemail` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` mediumtext NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `user_id`, `name`, `cemail`, `subject`, `message`, `updated_at`, `created_at`) VALUES
(4, 1, 'alsdkmasd', 'asdlkasd@gmail.com', 'ajsnfkansdf', 'alnfoajnflkamdfladkfnkjsndf', '2020-09-14 18:49:18', '2020-09-14 18:49:18'),
(5, 4, 'bla bla', 'asdmkasd@gmail.com', 'kalakjsd', 'lkamsdlkmasd message 2', '2020-09-15 19:02:14', '2020-09-15 19:02:14'),
(6, 4, 'asdasd', 'asdas@gmail.com', 'asdasd', 'asdaf', '2020-09-25 22:06:32', '2020-09-25 22:06:32'),
(7, 4, 'asdasdasd', 'ksakdjda@gmail.com', 'akdsjklajsd', 'ajosdiuhasds', '2020-09-25 22:19:31', '2020-09-25 22:19:31');

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE `contents` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `ctitle` varchar(255) NOT NULL,
  `carticle` longtext NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `link` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `data` text NOT NULL,
  `total` decimal(8,2) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `data`, `total`, `updated_at`, `created_at`) VALUES
(1, 1, 'a:3:{i:9;a:6:{s:2:\"id\";s:1:\"9\";s:4:\"name\";s:12:\"MIRA Red Dot\";s:5:\"price\";d:280;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:12:\"red dot.jpeg\";s:9:\"categorie\";s:11:\"attachments\";s:3:\"url\";s:12:\"mira-red-dot\";}s:10:\"conditions\";a:0:{}}i:5;a:6:{s:2:\"id\";s:1:\"5\";s:4:\"name\";s:17:\"M200 Intervention\";s:5:\"price\";d:12500;s:8:\"quantity\";i:2;s:10:\"attributes\";a:3:{s:5:\"image\";s:16:\"intervention.jpg\";s:9:\"categorie\";s:13:\"sniper-rifles\";s:3:\"url\";s:12:\"intervention\";}s:10:\"conditions\";a:0:{}}i:3;a:6:{s:2:\"id\";s:1:\"3\";s:4:\"name\";s:12:\"1911 Berreta\";s:5:\"price\";d:1200;s:8:\"quantity\";i:2;s:10:\"attributes\";a:3:{s:5:\"image\";s:11:\"berreta.jpg\";s:9:\"categorie\";s:8:\"handguns\";s:3:\"url\";s:7:\"berreta\";}s:10:\"conditions\";a:0:{}}}', '27680.00', '2020-07-28 18:49:00', '2020-07-28 18:49:00'),
(2, 4, 'a:2:{i:3;a:6:{s:2:\"id\";s:1:\"3\";s:4:\"name\";s:12:\"1911 Berreta\";s:5:\"price\";d:1200;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:11:\"berreta.jpg\";s:9:\"categorie\";s:8:\"handguns\";s:3:\"url\";s:7:\"berreta\";}s:10:\"conditions\";a:0:{}}i:4;a:6:{s:2:\"id\";s:1:\"4\";s:4:\"name\";s:8:\"Glock 19\";s:5:\"price\";d:1600;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:9:\"glock.jpg\";s:9:\"categorie\";s:8:\"handguns\";s:3:\"url\";s:8:\"glock-19\";}s:10:\"conditions\";a:0:{}}}', '2800.00', '2020-08-04 09:32:09', '2020-08-04 09:32:09'),
(3, 4, 'a:2:{i:4;a:6:{s:2:\"id\";s:1:\"4\";s:4:\"name\";s:8:\"Glock 19\";s:5:\"price\";d:1600;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:36:\"2020.09.14.19.06.18-A9eYo -glock.jpg\";s:9:\"categorie\";s:8:\"handguns\";s:3:\"url\";s:8:\"glock-19\";}s:10:\"conditions\";a:0:{}}i:3;a:6:{s:2:\"id\";s:1:\"3\";s:4:\"name\";s:12:\"1911 Berreta\";s:5:\"price\";d:1200;s:8:\"quantity\";i:3;s:10:\"attributes\";a:3:{s:5:\"image\";s:38:\"2020.09.14.19.05.33-kgy7T -berreta.jpg\";s:9:\"categorie\";s:8:\"handguns\";s:3:\"url\";s:7:\"berreta\";}s:10:\"conditions\";a:0:{}}}', '5200.00', '2020-09-14 20:17:32', '2020-09-14 20:17:32'),
(4, 3, 'a:4:{i:6;a:6:{s:2:\"id\";s:1:\"6\";s:4:\"name\";s:11:\"M82 Barrett\";s:5:\"price\";d:11700;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:38:\"2020.09.14.19.07.52-rifRC -barrett.jpg\";s:9:\"categorie\";s:13:\"sniper-rifles\";s:3:\"url\";s:7:\"barrett\";}s:10:\"conditions\";a:0:{}}i:5;a:6:{s:2:\"id\";s:1:\"5\";s:4:\"name\";s:17:\"M200 Intervention\";s:5:\"price\";d:12500;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:43:\"2020.09.14.19.06.56-hcj4E -intervention.jpg\";s:9:\"categorie\";s:13:\"sniper-rifles\";s:3:\"url\";s:12:\"intervention\";}s:10:\"conditions\";a:0:{}}i:4;a:6:{s:2:\"id\";s:1:\"4\";s:4:\"name\";s:8:\"Glock 19\";s:5:\"price\";d:1600;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:36:\"2020.09.14.19.06.18-A9eYo -glock.jpg\";s:9:\"categorie\";s:8:\"handguns\";s:3:\"url\";s:8:\"glock-19\";}s:10:\"conditions\";a:0:{}}i:3;a:6:{s:2:\"id\";s:1:\"3\";s:4:\"name\";s:12:\"1911 Berreta\";s:5:\"price\";d:1200;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:38:\"2020.09.14.19.05.33-kgy7T -berreta.jpg\";s:9:\"categorie\";s:8:\"handguns\";s:3:\"url\";s:7:\"berreta\";}s:10:\"conditions\";a:0:{}}}', '27000.00', '2020-09-14 20:18:08', '2020-09-14 20:18:08'),
(5, 1, 'a:5:{i:6;a:6:{s:2:\"id\";s:1:\"6\";s:4:\"name\";s:11:\"M82 Barrett\";s:5:\"price\";d:11700;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:38:\"2020.09.14.19.07.52-rifRC -barrett.jpg\";s:9:\"categorie\";s:13:\"sniper-rifles\";s:3:\"url\";s:7:\"barrett\";}s:10:\"conditions\";a:0:{}}i:9;a:6:{s:2:\"id\";s:1:\"9\";s:4:\"name\";s:12:\"MIRA Red Dot\";s:5:\"price\";d:280;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:39:\"2020.09.14.19.01.31-vmDdS -red dot.jpeg\";s:9:\"categorie\";s:11:\"attachments\";s:3:\"url\";s:12:\"mira-red-dot\";}s:10:\"conditions\";a:0:{}}i:8;a:6:{s:2:\"id\";s:1:\"8\";s:4:\"name\";s:14:\"CQR Front Grip\";s:5:\"price\";d:300;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:44:\"2020.09.14.19.00.44-MPj2w -cqr frontgrip.jpg\";s:9:\"categorie\";s:11:\"attachments\";s:3:\"url\";s:13:\"cqr-frontgrip\";}s:10:\"conditions\";a:0:{}}i:7;a:6:{s:2:\"id\";s:1:\"7\";s:4:\"name\";s:13:\"Trijicon ACOG\";s:5:\"price\";d:440;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:35:\"2020.09.14.18.59.49-FcSAi -acog.jpg\";s:9:\"categorie\";s:11:\"attachments\";s:3:\"url\";s:4:\"acog\";}s:10:\"conditions\";a:0:{}}i:10;a:6:{s:2:\"id\";s:2:\"10\";s:4:\"name\";s:14:\"Tactical Laser\";s:5:\"price\";d:180;s:8:\"quantity\";i:4;s:10:\"attributes\";a:3:{s:5:\"image\";s:37:\"2020.09.14.19.02.10-XTJPn -laser.jpeg\";s:9:\"categorie\";s:11:\"attachments\";s:3:\"url\";s:14:\"tactical-laser\";}s:10:\"conditions\";a:0:{}}}', '13440.00', '2020-09-14 20:18:54', '2020-09-14 20:18:54'),
(6, 4, 'a:1:{i:2;a:6:{s:2:\"id\";s:1:\"2\";s:4:\"name\";s:4:\"AK47\";s:5:\"price\";d:3500;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:35:\"2020.09.14.18.58.25-G9lYV -ak47.jpg\";s:9:\"categorie\";s:14:\"assault-rifles\";s:3:\"url\";s:4:\"ak47\";}s:10:\"conditions\";a:0:{}}}', '3500.00', '2020-09-20 17:29:35', '2020-09-20 17:29:35'),
(7, 4, 'a:8:{i:3;a:6:{s:2:\"id\";s:1:\"3\";s:4:\"name\";s:12:\"1911 Berreta\";s:5:\"price\";d:1200;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:38:\"2020.09.14.19.05.33-kgy7T -berreta.jpg\";s:9:\"categorie\";s:8:\"handguns\";s:3:\"url\";s:7:\"berreta\";}s:10:\"conditions\";a:0:{}}i:4;a:6:{s:2:\"id\";s:1:\"4\";s:4:\"name\";s:8:\"Glock 19\";s:5:\"price\";d:1600;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:36:\"2020.09.14.19.06.18-A9eYo -glock.jpg\";s:9:\"categorie\";s:8:\"handguns\";s:3:\"url\";s:8:\"glock-19\";}s:10:\"conditions\";a:0:{}}i:2;a:6:{s:2:\"id\";s:1:\"2\";s:4:\"name\";s:4:\"AK47\";s:5:\"price\";d:3500;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:35:\"2020.09.14.18.58.25-G9lYV -ak47.jpg\";s:9:\"categorie\";s:14:\"assault-rifles\";s:3:\"url\";s:4:\"ak47\";}s:10:\"conditions\";a:0:{}}i:1;a:6:{s:2:\"id\";s:1:\"1\";s:4:\"name\";s:4:\"M4A1\";s:5:\"price\";d:5000;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:33:\"2020.09.14.18.57.01-lRx2X -m4.jpg\";s:9:\"categorie\";s:14:\"assault-rifles\";s:3:\"url\";s:4:\"m4a1\";}s:10:\"conditions\";a:0:{}}i:6;a:6:{s:2:\"id\";s:1:\"6\";s:4:\"name\";s:11:\"M82 Barrett\";s:5:\"price\";d:11700;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:38:\"2020.09.14.19.07.52-rifRC -barrett.jpg\";s:9:\"categorie\";s:13:\"sniper-rifles\";s:3:\"url\";s:7:\"barrett\";}s:10:\"conditions\";a:0:{}}i:5;a:6:{s:2:\"id\";s:1:\"5\";s:4:\"name\";s:17:\"M200 Intervention\";s:5:\"price\";d:12500;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:43:\"2020.09.14.19.06.56-hcj4E -intervention.jpg\";s:9:\"categorie\";s:13:\"sniper-rifles\";s:3:\"url\";s:12:\"intervention\";}s:10:\"conditions\";a:0:{}}i:10;a:6:{s:2:\"id\";s:2:\"10\";s:4:\"name\";s:14:\"Tactical Laser\";s:5:\"price\";d:180;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:37:\"2020.09.14.19.02.10-XTJPn -laser.jpeg\";s:9:\"categorie\";s:11:\"attachments\";s:3:\"url\";s:14:\"tactical-laser\";}s:10:\"conditions\";a:0:{}}i:9;a:6:{s:2:\"id\";s:1:\"9\";s:4:\"name\";s:12:\"MIRA Red Dot\";s:5:\"price\";d:280;s:8:\"quantity\";i:1;s:10:\"attributes\";a:3:{s:5:\"image\";s:39:\"2020.09.14.19.01.31-vmDdS -red dot.jpeg\";s:9:\"categorie\";s:11:\"attachments\";s:3:\"url\";s:12:\"mira-red-dot\";}s:10:\"conditions\";a:0:{}}}', '35960.00', '2020-09-20 18:09:57', '2020-09-20 18:09:57');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `categorie_id` int(11) NOT NULL,
  `ptitle` varchar(255) NOT NULL,
  `particle` longtext NOT NULL,
  `description` longtext,
  `specifications` longtext,
  `highlights` text,
  `pimage` varchar(255) DEFAULT NULL,
  `pimage2` varchar(255) DEFAULT NULL,
  `pimage3` varchar(255) DEFAULT NULL,
  `pimage4` varchar(255) DEFAULT NULL,
  `pimage5` varchar(255) DEFAULT NULL,
  `price` decimal(10,0) NOT NULL,
  `purl` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `categorie_id`, `ptitle`, `particle`, `description`, `specifications`, `highlights`, `pimage`, `pimage2`, `pimage3`, `pimage4`, `pimage5`, `price`, `purl`, `created_at`, `updated_at`) VALUES
(1, 1, 'M4A1', 'm4 vla vla vla bla bla bla a good gun bla bla bla bla bla bllksld akjdf fdkjdf dkfjdf', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed semper sit amet sapien eget interdum. Vestibulum malesuada volutpat urna, in sollicitudin lorem tempor non. Fusce interdum nisi ipsum, sed feugiat.', 'consectetur adipiscing elit. Quisque nec risus sit amet quam feugiat mollis. Quisque a sapien ligula. Praesent suscipit diam sed lorem dignissim, efficitur maximus nulla tincidunt. Donec at vehicula massa. Integer mauris odio, aliquet vel tortor nec, vehicula ullamcorper sem. Proin ut nulla egestas, vehicula dui. sdksdkjskjd', '<p>fsdfsdf|sdfgfdg|Sdfsdf</p>', '2020.09.14.18.57.01-lRx2X -m4.jpg', '2020.09.14.18.57.30-g0NX7 -pimage3.jpg', '2020.09.14.18.57.42-CtnY4 -pimage2.jpg', '2020.09.14.18.57.53-guThe -pimage4.jpg', '2020.09.14.18.58.02-ZYNVt -pimage5.jpg', '5000', 'm4a1', '2020-06-29 22:30:40', '2020-09-14 18:58:02'),
(2, 1, 'AK47', 'ak47 vla vla vla bla bla bla a good gun bla bla bla bla bla bllksld akjdf fdkjdf dkfjdf', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed semper sit amet sapien eget interdum. Vestibulum malesuada volutpat urna, in sollicitudin lorem tempor non. Fusce interdum nisi ipsum, sed feugiat.', 'consectetur adipiscing elit. Quisque nec risus sit amet quam feugiat mollis. Quisque a sapien ligula. Praesent suscipit diam sed lorem dignissim, efficitur maximus nulla tincidunt. Donec at vehicula massa. Integer mauris odio, aliquet vel tortor nec, vehicula ullamcorper sem. Proin ut nulla egestas, vehicula dui.', NULL, '2020.09.14.18.58.25-G9lYV -ak47.jpg', '2020.09.14.18.58.43-7FYIx -pimage2.jpg', '2020.09.14.18.58.53-R2t2u -pimage3.jpg', '2020.09.14.18.59.03-3nqHF -pimage4.jpg', '2020.09.14.18.59.16-MSZH4 -pimage5.jpg', '3500', 'ak47', '2020-06-29 22:31:43', '2020-09-14 18:59:16'),
(3, 4, '1911 Berreta', 'berreta 1911 vla vla vla bla bla bla a good gun bla bla bla bla bla bllksld akjdf fdkjdf dkfjdf', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed semper sit amet sapien eget interdum. Vestibulum malesuada volutpat urna, in sollicitudin lorem tempor non. Fusce interdum nisi ipsum, sed feugiat.', 'consectetur adipiscing elit. Quisque nec risus sit amet quam feugiat mollis. Quisque a sapien ligula. Praesent suscipit diam sed lorem dignissim, efficitur maximus nulla tincidunt. Donec at vehicula massa. Integer mauris odio, aliquet vel tortor nec, vehicula ullamcorper sem. Proin ut nulla egestas, vehicula dui.', NULL, '2020.09.14.19.05.33-kgy7T -berreta.jpg', '2020.09.14.19.05.52-25AEK -pimage2.jpg', '2020.09.14.19.05.52-MvOmg -pimage3.jpg', '2020.09.14.19.05.52-mgNu0 -pimage4.jpg', '2020.09.14.19.06.01-Taqis -pimage5.jpg', '1200', 'berreta', '2020-06-29 22:32:40', '2020-09-14 19:06:01'),
(4, 4, 'Glock 19', 'glock 19 vla vla vla bla bla bla a good gun bla bla bla bla bla bllksld akjdf fdkjdf dkfjdf', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed semper sit amet sapien eget interdum. Vestibulum malesuada volutpat urna, in sollicitudin lorem tempor non. Fusce interdum nisi ipsum, sed feugiat.', 'consectetur adipiscing elit. Quisque nec risus sit amet quam feugiat mollis. Quisque a sapien ligula. Praesent suscipit diam sed lorem dignissim, efficitur maximus nulla tincidunt. Donec at vehicula massa. Integer mauris odio, aliquet vel tortor nec, vehicula ullamcorper sem. Proin ut nulla egestas, vehicula dui.v', NULL, '2020.09.14.19.06.18-A9eYo -glock.jpg', '2020.09.14.19.06.41-UwHlY -pimage2.jpg', '2020.09.14.19.06.41-9NNh9 -pimage3.jpg', '2020.09.14.19.06.41-5Hzn0 -pimage4.jpg', '2020.09.14.19.06.41-67h34 -pimage5.jpg', '1600', 'glock-19', '2020-06-29 22:33:21', '2020-09-14 19:06:41'),
(5, 6, 'M200 Intervention', 'intervention vla vla vla bla bla bla a good gun bla bla bla bla bla bllksld akjdf fdkjdf dkfjdf', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed semper sit amet sapien eget interdum. Vestibulum malesuada volutpat urna, in sollicitudin lorem tempor non. Fusce interdum nisi ipsum, sed feugiat.', 'consectetur adipiscing elit. Quisque nec risus sit amet quam feugiat mollis. Quisque a sapien ligula. Praesent suscipit diam sed lorem dignissim, efficitur maximus nulla tincidunt. Donec at vehicula massa. Integer mauris odio, aliquet vel tortor nec, vehicula ullamcorper sem. Proin ut nulla egestas, vehicula dui.', NULL, '2020.09.14.19.06.56-hcj4E -intervention.jpg', '2020.09.14.19.07.16-PM8WR -pimage2.jpg', '2020.09.14.19.07.16-FNc2q -pimage3.jpg', '2020.09.14.19.07.16-FN1XM -pimage4.jpg', '2020.09.14.19.07.23-1Evew -pimage5.jpg', '12500', 'intervention', '2020-06-29 22:34:03', '2020-09-14 19:07:23'),
(6, 6, 'M82 Barrett', 'barrett vla vla vla bla bla bla a good gun bla bla bla bla bla bllksld akjdf fdkjdf dkfjdf', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed semper sit amet sapien eget interdum. Vestibulum malesuada volutpat urna, in sollicitudin lorem tempor non. Fusce interdum nisi ipsum, sed feugiat.', 'consectetur adipiscing elit. Quisque nec risus sit amet quam feugiat mollis. Quisque a sapien ligula. Praesent suscipit diam sed lorem dignissim, efficitur maximus nulla tincidunt. Donec at vehicula massa. Integer mauris odio, aliquet vel tortor nec, vehicula ullamcorper sem. Proin ut nulla egestas, vehicula dui.', NULL, '2020.09.14.19.07.52-rifRC -barrett.jpg', '2020.09.14.19.08.11-1LmJZ -pimage2.jpg', '2020.09.14.19.08.11-yysM0 -pimage3.jpg', '2020.09.14.19.08.25-xzg8M -pimage4.jpg', '2020.09.14.19.08.25-A8rgD -pimage5.jpg', '11700', 'barrett', '2020-06-29 22:35:03', '2020-09-14 19:08:25'),
(7, 7, 'Trijicon ACOG', 'trijicon bla bla', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed semper sit amet sapien eget interdum. Vestibulum malesuada volutpat urna, in sollicitudin lorem tempor non. Fusce interdum nisi ipsum, sed feugiat.', 'consectetur adipiscing elit. Quisque nec risus sit amet quam feugiat mollis. Quisque a sapien ligula. Praesent suscipit diam sed lorem dignissim, efficitur maximus nulla tincidunt. Donec at vehicula massa. Integer mauris odio, aliquet vel tortor nec, vehicula ullamcorper sem. Proin ut nulla egestas, vehicula dui.', NULL, '2020.09.14.18.59.49-FcSAi -acog.jpg', '2020.09.14.19.00.10-fFmTq -pimage2.jpg', '2020.09.14.19.00.10-hx0TP -pimage3.jpg', '2020.09.14.19.00.21-cn16m -pimage4.jpg', '2020.09.14.19.00.21-Qy75M -pimage5.jpg', '440', 'acog', '2020-07-11 19:42:18', '2020-09-14 19:00:21'),
(8, 7, 'CQR Front Grip', 'cqr bla bla', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed semper sit amet sapien eget interdum. Vestibulum malesuada volutpat urna, in sollicitudin lorem tempor non. Fusce interdum nisi ipsum, sed feugiat.', 'consectetur adipiscing elit. Quisque nec risus sit amet quam feugiat mollis. Quisque a sapien ligula. Praesent suscipit diam sed lorem dignissim, efficitur maximus nulla tincidunt. Donec at vehicula massa. Integer mauris odio, aliquet vel tortor nec, vehicula ullamcorper sem. Proin ut nulla egestas, vehicula dui.', NULL, '2020.09.14.19.00.44-MPj2w -cqr frontgrip.jpg', '2020.09.14.19.01.11-f8pRH -pimage2.jpg', '2020.09.14.19.01.11-PH9KL -pimage3.jpg', '2020.09.14.19.01.11-8N0wv -pimage4.jpg', '2020.09.14.19.01.11-MuNGM -pimage5.jpg', '300', 'cqr-frontgrip', '2020-07-11 19:42:18', '2020-09-14 19:01:11'),
(9, 7, 'MIRA Red Dot', 'mira bla bla', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed semper sit amet sapien eget interdum. Vestibulum malesuada volutpat urna, in sollicitudin lorem tempor non. Fusce interdum nisi ipsum, sed feugiat.', 'consectetur adipiscing elit. Quisque nec risus sit amet quam feugiat mollis. Quisque a sapien ligula. Praesent suscipit diam sed lorem dignissim, efficitur maximus nulla tincidunt. Donec at vehicula massa. Integer mauris odio, aliquet vel tortor nec, vehicula ullamcorper sem. Proin ut nulla egestas, vehicula dui.', NULL, '2020.09.14.19.01.31-vmDdS -red dot.jpeg', '2020.09.14.19.01.55-O43nd -pimage2.jpg', '2020.09.14.19.01.55-AHueG -pimage3.jpg', '2020.09.14.19.01.55-xdJ9W -pimage4.jpg', '2020.09.14.19.01.55-5pCSP -pimage5.jpg', '280', 'mira-red-dot', '2020-07-11 19:44:17', '2020-09-14 19:01:55'),
(10, 7, 'Tactical Laser', 'laser bla bla', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed semper sit amet sapien eget interdum. Vestibulum malesuada volutpat urna, in sollicitudin lorem tempor non. Fusce interdum nisi ipsum, sed feugiat.', 'consectetur adipiscing elit. Quisque nec risus sit amet quam feugiat mollis. Quisque a sapien ligula. Praesent suscipit diam sed lorem dignissim, efficitur maximus nulla tincidunt. Donec at vehicula massa. Integer mauris odio, aliquet vel tortor nec, vehicula ullamcorper sem. Proin ut nulla egestas, vehicula dui.', NULL, '2020.09.14.19.02.10-XTJPn -laser.jpeg', '2020.09.14.19.02.58-OMhE0 -pimage2.jpg', '2020.09.14.19.02.58-FdTgA -pimage3.jpg', '2020.09.14.19.04.44-H5Pnh -laserrrrr.jpg_q50.jpg', '2020.09.14.19.03.23-OuowK -pimage5.jpg', '180', 'tactical-laser', '2020-07-11 19:44:17', '2020-09-14 19:04:44');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'dvir sabag', 'dvir@gmail.com', '$2y$10$m9UxE2pdCEJzmkQ6X2wehu1wvw1UXCLG76rXfBFcPx9K3ecJrGRKO', '2020-07-23 20:44:15', '2020-07-23 20:44:15'),
(2, 'dvir 2', 'dvir2@gmail.com', '$2y$10$o.kMvPZJABFwfdikY6oGGe6rmrp4JRHMtfgwKZMeofyM.hdFOJcuC', '2020-07-23 20:45:17', '2020-07-23 20:45:17'),
(3, 'dviron', 'dviron@gmail.com', '$2y$10$rVycfoH/Ww5x9p1/VFHf4.gaTDxms95Q7bBsWVBg.oLzaEm6wG1vy', '2020-07-25 17:54:55', '2020-07-25 17:54:55'),
(4, 'admin', 'admin@gmail.com', '$2y$10$rVycfoH/Ww5x9p1/VFHf4.gaTDxms95Q7bBsWVBg.oLzaEm6wG1vy', '2020-08-01 17:54:55', '2020-08-01 17:54:55'),
(5, 'ksdjfs', 'alskdmsd@gmail.com', '$2y$10$/.yMWtpaTbzSW4uU4y5o6.kVA/4v9Iv9SptdrOS/Jib5nCY.HdA5G', '2020-09-25 22:35:11', '2020-09-25 22:35:11');

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `uid` int(11) NOT NULL,
  `rid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`uid`, `rid`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 2),
(5, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `contents`
--
ALTER TABLE `contents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_id` (`menu_id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `purl` (`purl`),
  ADD KEY `categorie_id` (`categorie_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contents`
--
ALTER TABLE `contents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contents`
--
ALTER TABLE `contents`
  ADD CONSTRAINT `contents_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
