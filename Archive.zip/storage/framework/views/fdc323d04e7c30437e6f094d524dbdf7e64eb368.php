<?php $__env->startSection('cms_content'); ?>
   
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->

   

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php $__env->startComponent('components.cms_components'); ?>
        <?php $__env->slot('title'); ?>Orders
        <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
    
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-12">
        <div class="card shadow mb-4 text-center">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Completed Orders</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                  
                   <th>User</th>
                   <th>Total</th>
                   <th>Order Details</th>
                   <th>Order Date</th>
                   
                    </tr>
                  </thead>
                
                  <tbody>
                 <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($order->email); ?></td>
                  <td>$<?php echo e($order->total); ?></td>
                  <td>
                <ul>
                <?php $__currentLoopData = unserialize($order->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <li>

                    <b><?php echo e($item['name']); ?> </b> 
                    <b>Price: </b>$<?php echo e($item['price']); ?>

                    <b>Quantity: </b><?php echo e($item['quantity']); ?>

            
                    
                </li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
                  </td>
                  <td><?php echo e(date('d/m/Y H:i:s',strtotime($order->created_at))); ?></td>
                </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
                  </tbody>
                </table>
                <div class="row mb-5">
                  <div class="col-12">
                     <?php echo e($orders->links()); ?>


                 </div>

                </div>
                
              </div>
            </div>
        </div>
          </div>


  </div>
</div>
  <!-- /.container-fluid -->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/cms/orders.blade.php ENDPATH**/ ?>