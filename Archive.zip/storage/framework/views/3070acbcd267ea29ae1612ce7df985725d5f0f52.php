<?php $__env->startSection('cms_content'); ?>
   
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->

   

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php $__env->startComponent('components.cms_components'); ?>
        <?php $__env->slot('title'); ?>Edit Content
        <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>

    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Set Up Your Content</h6>
            </div>
            <div class="card-body">
              <form id="edit-content-form" action="<?php echo e(url('cms/content/'.$item->id )); ?>" method="POST" autocomplete="off" novalidate="novalidate" class="my-form">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PUT')); ?>

                  <div class="form-group">
                    <label for="menu_id">* Menu Link</label>
                    <select class="form-control" name="menu" id="menu">
                    
                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if( $item->menu_id == $menu_item->id ): ?> selected="selected"
                        <?php endif; ?>
                         value="<?php echo e($menu_item->id); ?>"><?php echo e($menu_item->link); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="text-danger"><?php echo e($errors->first('menu')); ?></span>
                </div>
<div class="form-group">
    <label for="title">* Content Title</label>
    <input value="<?php echo e($item->ctitle); ?>" type="text" name="title" id="title" class="form-control">
    <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
</div>
<div class="form-group">
    <label for="title">* Content Article</label>
<textarea class="form-control" name="article" id="article" cols="30" rows="10"><?php echo e(old('article',$item->carticle)); ?></textarea>
    <span class="text-danger"><?php echo e($errors->first('article')); ?></span>
</div>
<button type="submit" class="btn btn-success mr-3" name="submit">Save</button>
<a href="<?php echo e(url('cms/content')); ?>" type="button" class="btn btn-light">Cancel</a>

              </form>
            </div>
        </div>
          </div>
  </div>
  <!-- /.container-fluid -->
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/cms/content_edit.blade.php ENDPATH**/ ?>