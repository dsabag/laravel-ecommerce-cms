<?php

$menu = App\Menu::all();
$page_title = 'Page Not Found';
$categories = App\Categorie::all();

?>

<?php $__env->startSection('main_content'); ?>
<section class="breadcumb-area jarallax bg-img af">
    <div class="breadcumb">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="content">
                        <h2>404 - Page Not Found</h2>
                      <?php $__env->startComponent('components.url_link'); ?>
                          <?php $__env->slot('home'); ?>
                          <?php $__env->endSlot(); ?>
                          <?php $__env->slot('page_name'); ?>
                          <?php $__env->endSlot(); ?>
                      <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="about-area section bg-img jarallax">
      
        <div class="container">
            <div class="row">
                <div class="col-md-7 col-sm-12">
                    <div class="section-heading2">
                    <h2>This Page Has Been Shot... <a href="<?php echo e(url('')); ?>">Go Home</a></h2>
                    </div>
                    
                </div>
                
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/errors/404.blade.php ENDPATH**/ ?>