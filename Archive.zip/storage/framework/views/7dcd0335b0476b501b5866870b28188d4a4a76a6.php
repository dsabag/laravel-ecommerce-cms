<?php $__env->startSection('main_content'); ?>

  <!--Breadcumb area start here-->
  <section class="breadcumb-area jarallax bg-img af">
    <div class="breadcumb">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="content">
                        <h2>Categories</h2>
                        <?php $__env->startComponent('components.url_link'); ?>
                        <?php $__env->slot('home'); ?>Home
                        <?php $__env->endSlot(); ?>
                        <?php $__env->slot('page_name'); ?>Categories
                        <?php $__env->endSlot(); ?>
                    <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Breadcumb area end here-->

<!-- categories start here -->
<section class="shop-page section bg-img jarallax">
    <div class="container">
<div class="row">
    <div class="col-md-12 col-sm-12 pd-0">
        <div class="pro-sliders">
           <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-sm-12">
            <div class="products">
            <figure><img height="250" src="<?php echo e(asset('images/'.$categorie->image)); ?> "alt="" /></figure>
                <div class="contents">
                <h3><?php echo e($categorie->title); ?></h3>
                    <br>
                    <a href="<?php echo e(url('shop/'.$categorie->url)); ?>" class="btn4">View Products</a>
                </div>
            </div>
        </div>
               
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>
</div>

</section>
<!--categories area end here-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/shop.blade.php ENDPATH**/ ?>