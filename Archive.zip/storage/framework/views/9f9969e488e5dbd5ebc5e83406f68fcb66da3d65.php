<?php $__env->startSection('cms_content'); ?>
   
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->

   

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php $__env->startComponent('components.cms_components'); ?>
        <?php $__env->slot('title'); ?>Edit Menu Link
        <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>

    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Edit Your Link</h6>
            </div>
            <div class="card-body">
            <form id="add-menu-form" action="<?php echo e(url('cms/menu/'.$item->id )); ?>" method="POST" autocomplete="off" novalidate="novalidate" class="my-form">
                  <?php echo csrf_field(); ?>
                  <?php echo e(method_field('PUT')); ?>

            <input type="hidden" name="item_id" value="<?php echo e($item->id); ?>">
<div class="form-group">
    <label for="link">* Menu Link</label>
<input value="<?php echo e($item->link); ?>" type="text" name="link" id="link" class="form-control origin">
<span class="text-danger"><?php echo e($errors->first('link')); ?></span>
</div>
<div class="form-group">
    <label for="url">* Menu Url <small><i>(Friendly Url, Lowercase, Numbers, Hyphen)</i> </small></label>
    <input value="<?php echo e($item->url); ?>" type="text" name="url" id="url" class="form-control target">
    <span class="text-danger"><?php echo e($errors->first('url')); ?></span>
</div>
<div class="form-group">
    <label for="title">* Page Title</label>
    <input value="<?php echo e($item->title); ?>" type="text" name="title" id="title" class="form-control">
    <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
</div>
<button type="submit" class="btn btn-success mr-3" name="submit">Save Changes</button>
<a href="<?php echo e(url('cms/menu')); ?>" type="button" class="btn btn-light">Cancel</a>

              </form>
            </div>
        </div>
          </div>


  </div>
  <!-- /.container-fluid -->
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/cms/menu_edit.blade.php ENDPATH**/ ?>