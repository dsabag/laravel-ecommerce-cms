<!doctype html>
<html class="no-js" lang="en">
   
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--Theme Title-->
<title><?php echo e($page_title); ?></title>
    <meta name="description" content="">

    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/icon" href="images/icon.ico" />

    <!-- All css Here -->
    <!-- All plugins css -->
<link rel="stylesheet" href="<?php echo e(asset('lib/guns/html/assets/css/allplugins.css')); ?>">
    <!-- Style css -->
<link rel="stylesheet" href="<?php echo e(asset('lib/guns/html/assets/style.css')); ?>">
    <!-- Responsive css -->
<link rel="stylesheet" href="<?php echo e(asset('lib/guns/html/assets/css/responsive.css')); ?>">


    <!-- Customization css -->
    <!--If u need any change then use this css file-->
<link rel="stylesheet" href="<?php echo e(asset('lib/guns/html/assets/css/custom.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">

    <!-- Modernizr JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>

<script> var BASE_URL = "<?php echo e(url('')); ?>/" ; </script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
                <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
                <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
            <![endif]-->
</head>

<body>
    <div id="preloader">
    <div id="status"><img src="<?php echo e(asset('lib/guns/html/assets/images/logo/preloader.gif')); ?>" id="preloader_image" alt="loader">
        </div>
    </div>
    <!--Preloader area End-->

    <!--Header area start here-->
    <header>

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                        <?php if(!Session::has('user_id')): ?>
                        <div class="my-btn">
                                <a href="<?php echo e(url('user/signin')); ?>" class="btn3">SIGN IN</a> | 
                        <a href="<?php echo e(url('user/signup')); ?>" class="btn3">SIGN UP</a>
                            </div>
                            <?php else: ?>
                            <div class="sing-in-btn buttons my-btn">
                                <?php if(Session::get('is_admin')): ?>
                                    <a href="<?php echo e(url('cms/dashboard')); ?>" class="dash-btn">Dashboard</a> |
                                    <?php endif; ?>
                                    <a href="<?php echo e(url('user/logout')); ?>" class="btn3">Logout</a> | 
                            <span class="text-primary"><?php echo e(Session::get('user_name')); ?></span>

                            <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2 col-sm-2 col-xs-5">
                  
                    <a href="<?php echo e(url('')); ?>"><img src="<?php echo e(asset('lib/guns/html/assets/images/logo/logo.png')); ?>" id="logo" alt=""/></a>
                
                </div>
                
                <div class="col-md-10 col-sm-10 hidden-xs">
                    <div class="main-header my-nav">
                        <div class="main-menus">
                            <nav>
                                <ul class="mamnu">
                                <li><a href="<?php echo e(url('')); ?>">Home</a></li>
                                    <li><a href="<?php echo e(url('about')); ?>">About</a></li>
                                    <li>
                                            <a href="<?php echo e(url('contact')); ?>">Contact</a> 
                                       
                                    </li>
                                    <li>
                                        <a href="<?php echo e(url('gallery')); ?>">Gallery</a>
                                      
                                    </li>
                                        <?php if(!empty($menu)): ?>
                                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                    <a href="<?php echo e(url($menu_item->url)); ?>"><?php echo e($menu_item->link); ?></a>
                                          
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <li><a href="<?php echo e(url('shop')); ?>">shop</a></li>
                                    </li>
                                  
                                   
                                </ul>
                            </nav>
                        </div>
                      
                        <div class="cart-head">
                    <button>
                        <?php if(!Cart::isEmpty()): ?>
                        <span class="total-in-cart"><?php echo e(Cart::getTotalQuantity()); ?></span>
                        <?php endif; ?>
                        <i class="fas fa-shopping-cart"></i></button>
                            <div class="nav-shop-cart">
                                <div class="widget_shopping_cart_content">
                                    <ul class="product_list_widget">
                                       <?php $__currentLoopData = Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      
                                       <li class="mini_cart_item">
                                           
                                       <a href="<?php echo e(url('shop/'.$item->attributes->categorie.'/'.$item->attributes->url)); ?>">
                                            <img src="<?php echo e(asset('images/'.$item->attributes->image)); ?>" alt="" />
                                                <p class="product-name"><?php echo e($item->name); ?></p>
                                            </a>

                                            <p class="quantity"><?php echo e($item->quantity); ?>x
                                                <strong class="Price-amount">$<?php echo e($item->price); ?></strong>
                                            </p>

                                        <a data-pid="<?php echo e($item['id']); ?>" class="remove remove-from-cart-btn" title="Remove this item">x</a>
                                        </li>
                                        
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      
                                    <!-- /.product_list_widget -->
                                            
                                    <?php if(!Cart::isEmpty()): ?>
                                    <p class="total">
                                        <strong>Total:</strong>
                                        <span class="amount">$<?php echo e(Cart::getTotal()); ?>

                                                </span>
                                    </p>

                                    <p class="buttons text-center">
                                    <a href="<?php echo e(url('shop/cart')); ?>" class="btn1">Checkout</a>
                                     
                                    </p>
                                    <?php else: ?>

                                    <p class="buttons text-center">
                                        <button disabled="disabled">Cart Is Empty</button>
                                         
                                        </p>

                                    <?php endif; ?>  
                                            
                                  
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>

        <!--Responsive Menu area-->
        <div class="mobilemenu">
               
            <div class="mobile-menu visible-xs">

                <nav>
                           
                    <ul>
                            <li><a href="<?php echo e(url('')); ?>">Home</a></li>
                            <li><a href="<?php echo e(url('about')); ?>">About</a></li>
                            <li>
                                    <a href="<?php echo e(url('contact')); ?>">Contact</a> 
                               
                            </li>
                            <li>
                                <a href="<?php echo e(url('gallery')); ?>">Gallery</a>
                              
                            </li>
                                <?php if(!empty($menu)): ?>
                            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                            <a href="<?php echo e(url($menu_item->url)); ?>"><?php echo e($menu_item->link); ?></a>
                                  
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <li><a href="<?php echo e(url('shop')); ?>">shop</a></li>
                            <li>
                            <?php if(!Cart::isEmpty()): ?>
                            <span class="total-in-cart-mobile text-center"><?php echo e(Cart::getTotalQuantity()); ?></span>
                            <?php endif; ?>
                            
                            <a href="<?php echo e(url('shop/cart')); ?>">Shopping Cart &nbsp; <i class="fas fa-shopping-cart text-warning"></i></a>
                            </li>
                    </ul>
                </nav>
            </div>
        </div>
        <!--Responsive Menu area End-->
    </header>
    <!--Header area end here-->
    
    <?php echo $__env->yieldContent('main_content'); ?>
    <!--Footer area start here-->
    <footer class="jarallax">
        <div class="footer-top section">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-sm-6">
                        <div class="foo-about">
                        <figure><img src="<?php echo e(asset('lib/guns/html/assets/images/logo/logo.png')); ?>" alt="" /></figure>
                            <div class="contents">
                                <p>All modern weapon lovers can appreciate our broad services and real-world, experienced staff. With state-of-the-art indoor training facilities and full service.</p>
                             
                            </div>
                            <ul class="foo-social">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-youtube"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                    </div>
                  
                    <div class="col-md-4 col-sm-6 clear-cart">
                        <h2>Shop Categories</h2>
                        <div class="products-foo">
                            <ul>
                               
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <li>
                            <a href="<?php echo e(url('shop/' . $categorie['url'])); ?>"><img height="80" src="<?php echo e(asset('images/'.$categorie['image'])); ?>" alt="" /></a>
                             </li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <p>For More Products and Guns Click Here!</p>
                            <a href="<?php echo e(url('shop')); ?>" class="btn1">Our Shop</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="copyright sm-t-center">
                            <p>Copyright © <?php echo e(date('Y')); ?> <a href="<?php echo e(url('about')); ?>"><span>Son Of A Gun.</span> </a> Design by <a href="<?php echo e(url('contact')); ?>"><span>Dvir Sabag</span></a></p>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="foo-links sm-t-center">
                            <ul>
                                <li><a href="<?php echo e(url('/')); ?>">Privacy Policy</a></li>
                                <li><a href="<?php echo e(url('/')); ?>">Terms & Conditions</a></li>
                                <li><a href="<?php echo e(url('/')); ?>">Copyright Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--Footer area end here-->

    <!-- All JavaScript Here -->

    <!-- jQuery latest version -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <!-- tether JavaScript -->
    <script src="<?php echo e(asset('lib/guns/html/assets/js/tether.min.js')); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/bootstrap.min.js')); ?>"></script>
    <!-- Owl.carousel JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/owl.carousel.min.js')); ?>"></script>
    <!-- Bxslider JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/jquery.bxslider.min.js')); ?>"></script>
    <!-- isotope JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/isotope.pkgd.min.js')); ?>"></script>
    <!-- Magnific Popup JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/jquery.magnific-popup.min.js')); ?>"></script>
    <!-- meanmenu JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/jquery.meanmenu.js')); ?>"></script>
    <!-- jarallax JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/jarallax.min.js')); ?>"></script>
    <!-- jQuery-ui JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/jquery-ui.min.js')); ?>"></script>
    <!-- Progressbar Animation JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/guns/html/assets/js/jquery.counterup.min.js')); ?>"></script>
    <!-- masonry JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/masonry.pkgd.min.js')); ?>"></script>
    <!-- bootstrap-touchspin JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/jquery.bootstrap-touchspin.min.js')); ?>"></script>
    <!-- downCount JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/jquery.downCount.js')); ?>"></script>
    <!-- wow JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/wow.min.js')); ?>"></script>
    <!-- slick JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/slick.min.js')); ?>"></script>
    <!-- Plugins JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/plugins.js')); ?>"></script>
    <!-- Init JavaScript -->
<script src="<?php echo e(asset('lib/guns/html/assets/js/main.js')); ?>"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<?php if(Session::has('success')): ?>
<script>
toastr.options.positionClass = 'toast-bottom-left';
toastr.success("<?php echo e(Session::get('success')); ?>");

</script>
<?php endif; ?>
<?php if(Session::has('error')): ?>
<script>
toastr.options.positionClass = 'toast-bottom-left';
toastr.error("<?php echo e(Session::get('error')); ?>");

</script>
<?php endif; ?>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>

  
</body>

</html><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/master.blade.php ENDPATH**/ ?>