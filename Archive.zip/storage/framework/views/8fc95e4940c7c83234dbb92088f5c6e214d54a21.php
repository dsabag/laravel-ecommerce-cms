<?php $__env->startSection('main_content'); ?>

 <!--Breadcumb area start here-->
 <section class="breadcumb-area jarallax bg-img af">
        <div class="breadcumb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="content">
                            <h2><?php echo e($categorie_name[0]->title.' | '.$product->ptitle); ?></h2>
                            <?php $__env->startComponent('components.url_link'); ?>
                            <?php $__env->slot('home'); ?>Home
                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('page_name'); ?><?php echo e($product->ptitle); ?>

                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Breadcumb area end here-->
    <!--Product Details area start here-->
    <section class="product-details section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="products-photo">
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="img1">
                            <img height="355" width="523" src="<?php echo e(asset('images/'.$product->pimage2)); ?>" alt="" />
                            </div>
                            <div role="tabpanel" class="tab-pane" id="img2">
                                <img height="355" width="523" src="<?php echo e(asset('images/'.$product->pimage3)); ?>" alt="" />
                            </div>
                            <div role="tabpanel" class="tab-pane" id="img3">
                                <img height="355" width="523" src="<?php echo e(asset('images/'.$product->pimage4)); ?>" alt="" />
                            </div>
                            <div role="tabpanel" class="tab-pane" id="img4">
                                <img height="355" width="523" src="<?php echo e(asset('images/'.$product->pimage5)); ?>" alt="" />
                            </div>
                        </div>
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                            <a href="#img1" role="tab" data-toggle="tab"><img height="80" width="150" src="<?php echo e(asset('images/'.$product->pimage2)); ?>" alt="" /></a>
                            </li>
                            <li role="presentation">
                                <a href="#img2" role="tab" data-toggle="tab"><img height="80" width="150" src="<?php echo e(asset('images/'.$product->pimage3)); ?>" alt="" /></a>
                            </li>
                            <li role="presentation">
                                <a href="#img3" role="tab" data-toggle="tab"><img height="80" width="150" src="<?php echo e(asset('images/'.$product->pimage4)); ?>" alt="" /></a>
                            </li>
                            <li role="presentation">
                                <a href="#img4" role="tab" data-toggle="tab"><img height="80" width="150" src="<?php echo e(asset('images/'.$product->pimage5)); ?>" alt="" /></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="single-product-content">
                    <h2><?php echo e($product->ptitle); ?></h2>
                        <div class="product-review">
                            <ul>
                                <li><i class="fa fa-star"></i></li>
                                <li><i class="fa fa-star"></i></li>
                                <li><i class="fa fa-star"></i></li>
                                <li><i class="fa fa-star"></i></li>
                                <li><i class="fa fa-star"></i></li>
                            </ul>
                            <span>10 Reviews</span>
                       
                        </div>
                        <div class="con">
                        <p><?php echo e($product->particle); ?></p>
                            <ul>
                                <?php if($highlights): ?>
                              <?php $__currentLoopData = $highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li><i class="fa fa-angle-double-right"></i><?php echo $highlight; ?></li>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                            </ul>
                        </div>
                      
                        <div class="price">
                            <strong>$<?php echo e($product->price); ?></strong>
                            <del>$<?php echo e($product->price + 500); ?></del>
                            <span>($500 OFF)</span>
                        </div>
                        <div class="buttons">
                                <?php if(!Cart::get($product->id)): ?>
                                <button data-pid="<?php echo e($product->id); ?>" class="btn1 add-to-cart-btn"><i class="fas fa-cart-plus"></i>  Add To Cart</button>
            
                                <?php else: ?>
                                <button data-pid="<?php echo e($product->id); ?>" class="btn1 btn-success add-to-cart-btn" disabled="disabled"><i class="fas fa-thumbs-up"></i> Item In Cart</button>
            
                                <?php endif; ?>

                            <a href="<?php echo e(url('shop/cart')); ?>" class="btn4">Checkout</a>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row section5">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    
                    <div class="pro-details">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">

                           <?php if($product->description): ?> <li role="presentation" class="active"><a href="#con1" role="tab" data-toggle="tab">Description</a></li><?php endif; ?>
                           <?php if($product->specifications): ?> <li role="presentation"><a href="#con2" role="tab" data-toggle="tab">Specification</a></li><?php endif; ?>
                          
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="con1">
                                <div class="con">
                                 
                                <p><?php echo $product->description; ?></p>
                                   
                                </div>
                            </div>
                           
                            <div role="tabpanel" class="tab-pane" id="con2">
                                <div class="con">
                                    
                                    <p>
                                    <?php echo $product->specifications; ?>

                                    </p>
                                   
                                </div>
                            </div>
                            
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
    </section>
    <!--Product Details area End here-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/details.blade.php ENDPATH**/ ?>