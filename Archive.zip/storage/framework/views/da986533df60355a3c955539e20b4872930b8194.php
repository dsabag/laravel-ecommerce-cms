<?php $__env->startSection('cms_content'); ?>
   
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->

   

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php $__env->startComponent('components.cms_components'); ?>
        <?php $__env->slot('title'); ?>Product
        <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>

    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Are You Sure You Want To Delete This Product?</h6>
            </div>
            <div class="card-body">
            <form action="<?php echo e(url('cms/products/'.$item_id)); ?>" method="POST" autocomplete="off" novalidate="novalidate" class="my-form">
                  <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

            <button type="submit" class="btn btn-danger mr-3" name="submit">Delete</button>
            <a href="<?php echo e(url('cms/products')); ?>" type="button" class="btn btn-light">Cancel</a>

              </form>
            </div>
        </div>
          </div>


  </div>
  <!-- /.container-fluid -->
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/cms/product_delete.blade.php ENDPATH**/ ?>