<?php $__env->startSection('main_content'); ?>
<section class="breadcumb-area jarallax bg-img af">
    <div class="breadcumb">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="content">
                        <h2>About us</h2>
                      <?php $__env->startComponent('components.url_link'); ?>
                          <?php $__env->slot('home'); ?>Home
                          <?php $__env->endSlot(); ?>
                          <?php $__env->slot('page_name'); ?>About Us
                          <?php $__env->endSlot(); ?>
                      <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
   <!--About area start here-->
   <section class="about-area section bg-img jarallax">
      
    <div class="container">
        <div class="row">
            <div class="col-md-7 col-sm-12">
                <div class="section-heading2">
                    <h2>Who We Are</h2>
                </div>
                <div class="about-contents">
                    <p>With state-of-the-art indoor training facilities and full service custom on-line shop, we can accommodate most requests. All modern weapon lovers can appreciate our broad services and real-world, experienced staff. With state-of-the-art indoor training facilities and full service.</p>
                    <blockquote>“This site will revolutionize the purchasing process of silencers, SBRs, AR's and in their class, can accommodate most.”</blockquote>
                    <p>Our goal is to be the single point of service military and veteran Weapons needs. We connect with our audience through our website which averages 4 milllion unique visitors a month</p>
                    <div class="buttons">
                        <a href="<?php echo e(url('shop')); ?>" class="btn1">Our Shop</a>
                        
                    </div>
                </div>
            </div>
            <div class="col-md-5 col-sm-12 ">
                <div class="about-cata">
                    <div class="cata-list list-t1">
                        <div class="dbox">
                            <div class="dleft">
                                <div class="content">
                                    <h4>Hunting</h4>
                               
                                </div>
                            </div>
                            <div class="dright">
                                <div class="cate-ico">
                                    <img src="<?php echo e(asset('lib/guns/html/assets/images/icons/01.png')); ?>" alt="" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="cata-list list-t2">
                        <div class="dbox">
                            <div class="dleft">
                                <div class="content">
                                    <h4>Training</h4>
                                   
                                </div>
                            </div>
                            <div class="dright">
                                <div class="cate-ico">
                                <img src="<?php echo e(asset('lib/guns/html/assets/images/icons/02.png')); ?>" alt="" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="cata-list list-t1">
                        <div class="dbox">
                            <div class="dleft">
                                <div class="content">
                                    <h4>Shooting Range</h4>
                                    
                                </div>
                            </div>
                            <div class="dright">
                                <div class="cate-ico">
                                    <img src="<?php echo e(asset('lib/guns/html/assets/images/icons/03.png')); ?>" alt="" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--About area end here-->
<!--Partner area start here-->
<section class="partner-area section bg-img jarallax">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <div class="section-heading">
                    <h2>Our Trusted Partners</h2>
                    <p>All modern weaponts can appreciate our broad services akshay handge pharetra, eratd fermentum feugiat, gun are best velit mauris aks egestasut aliquam.</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12">
                    <div class="partner-list">
                            <ul>
                                <li>
                                <a href="http://www.greenvilleyouthfootball.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/1.png')); ?>" alt="" /></a>
                                </li>
                                <li>
                                <a href="https://jeans.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/2.png')); ?>" alt="" /></a>
                                </li>
                                <li>
                                <a href="https://www.dressmakerschoice.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/3.png')); ?>" alt="" /></a>
                                </li>
                                <li>
                                <a href="http://www.medley.co.uk/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/4.png')); ?>" alt="" /></a>
                                </li>
                                <li>
                                 <a href="https://azpbs.org/tv/arizonacollection/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/5.png')); ?>" alt="" /></a>
                                </li>
                                <li>
                                 <a href="https://www.woodn.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/6.png')); ?>" alt="" /></a>
                                </li>
                                <li>
                                 <a href="https://www.advisorclient.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/7.png')); ?>" alt="" /></a>
                                </li>
                                <li>
                                <a href="https://folioclient.com/fc-index.jsp"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/8.png')); ?>" alt="" /></a>
                                </li>
                                <li>
                                 <a href="https://goals.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/9.png')); ?>"alt="" /></a>
                                </li>
                                <li>
                                 <a href="http://olympiaoceancarriers.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/10.png')); ?>" alt="" /></a>
                                </li>
                            </ul>
                        </div>
            </div>
        </div>
    </div>
</section>
<!--Partner area End here-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/about.blade.php ENDPATH**/ ?>