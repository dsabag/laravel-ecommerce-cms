<?php $__env->startSection('cms_content'); ?>
   
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->

   

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php $__env->startComponent('components.cms_components'); ?>
        <?php $__env->slot('title'); ?>Add A New Product
        <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>

    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Set Up Your Product</h6>
            </div>
            <div class="card-body">
            <form id="add-product-form" action="<?php echo e(url('cms/products')); ?>" method="POST" autocomplete="off" novalidate="novalidate" class="my-form" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>

                  <div class="form-group">
<label for="categorie-id">* Product Category</label>
<select class="form-control" name="category" id="categorie-id">

<option value="">Choose Category...</option>

<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<option <?php if( old('category') == $category->id ): ?> selected="selected" <?php endif; ?> value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<span class="text-danger"><?php echo e($errors->first('category')); ?></span>

                  </div>
<div class="form-group">
    <label for="title">* Product Title</label>
<input value="<?php echo e(old('title')); ?>" type="text" name="title" id="title" class="form-control origin">
<span class="text-danger"><?php echo e($errors->first('title')); ?></span>
</div>
<div class="form-group">
    <label for="url">* Url <small><i>(Friendly Url, Lowercase, Numbers, Hyphen)</i> </small></label>
    <input value="<?php echo e(old('url')); ?>" type="text" name="url" id="url" class="form-control target">
    <span class="text-danger"><?php echo e($errors->first('url')); ?></span>
</div>
<div class="form-group">
  <label for="price">* Product Price</label>
<input value="<?php echo e(old('price')); ?>" type="text" name="price" id="title" class="form-control">
<span class="text-danger"><?php echo e($errors->first('price')); ?></span>
</div>
<div class="form-group">
    <label for="about">* About</label>
    <input value="<?php echo e(old('about')); ?>" type="text" name="about" class="form-control">
    <span class="text-danger"><?php echo e($errors->first('about')); ?></span>
</div>
<div class="form-group">
    <label for="description">Description <small><i>(Optional)</i> </small></label>
<textarea class="form-control article" name="description" cols="30" rows="10"><?php echo e(old('description')); ?></textarea>
    <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
</div>
<div class="form-group">
    <label for="specs">Specifications <small><i>(Optional)</i> </small></label>
<textarea class="form-control article" name="specs" cols="30" rows="10"><?php echo e(old('specs')); ?></textarea>
    <span class="text-danger"><?php echo e($errors->first('specs')); ?></span>
</div>
<div class="form-group">
    <label for="highlights">Properties <small><i>(Optional, Please Use " | " Between Properties)</i> </small></label>
<textarea class="form-control article" name="highlights" cols="15" rows="5"><?php echo e(old('highlights')); ?></textarea>
    <span class="text-danger"><?php echo e($errors->first('highlights')); ?></span>
</div>

<div class="form-group"><label for="image">Product Main Image <small><i>(Optional)</i> </small></label></div>
<div class="input-group">
    <div class="input-group-prepend">
      <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
    </div>
    <div class="custom-file">
      <input type="file" name="image" class="image-upload custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
      <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
    </div>
  </div>
  <div class="form-group mb-5">
    <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
  </div>

  <div class="form-group"><label for="image2">Product Image 2<small><i>(Optional)</i> </small></label></div>
<div class="input-group">
    <div class="input-group-prepend">
      <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
    </div>
    <div class="custom-file">
      <input type="file" name="image2" class="image-upload custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
      <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
    </div>
  </div>
  <div class="form-group mb-5">
    <span class="text-danger"><?php echo e($errors->first('image2')); ?></span>
  </div>

  <div class="form-group"><label for="image3">Product Image 3<small><i>(Optional)</i> </small></label></div>
  <div class="input-group">
      <div class="input-group-prepend">
        <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
      </div>
      <div class="custom-file">
        <input name="image3" type="file" class="image-upload custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
        <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
      </div>
    </div>
    <div class="form-group mb-5">
      <span class="text-danger"><?php echo e($errors->first('image3')); ?></span>
    </div>

    <div class="form-group"><label for="image2">Product Image 4<small><i>(Optional)</i> </small></label></div>
    <div class="input-group">
        <div class="input-group-prepend">
          <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
        </div>
        <div class="custom-file">
          <input name="image4" type="file" class="image-upload custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
          <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
        </div>
      </div>
      <div class="form-group mb-5">
        <span class="text-danger"><?php echo e($errors->first('image4')); ?></span>
      </div>

      <div class="form-group"><label for="image5">Product Image 5<small><i>(Optional)</i> </small></label></div>
      <div class="input-group">
          <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
          </div>
          <div class="custom-file">
            <input name="image5" type="file" class="image-upload custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
          </div>
        </div>
        <div class="form-group mb-5">
          <span class="text-danger"><?php echo e($errors->first('image5')); ?></span>
        </div>




  <div class="form-group mb-5">
<button type="submit" class="btn btn-success mr-3" name="submit">Save</button>
<a href="<?php echo e(url('cms/products')); ?>" type="button" class="btn btn-light">Cancel</a>
</div>

              </form>
            </div>
        </div>
          </div>


  </div>
  <!-- /.container-fluid -->
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/cms/products_create.blade.php ENDPATH**/ ?>