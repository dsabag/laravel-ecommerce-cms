<ul>
    <li><a href="<?php echo e(url('')); ?>"><?php echo e($home); ?></a></li>
    <li><a href="javascript:void(0)"><?php echo e($page_name); ?></a></li>
</ul>
<?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/components/url_link.blade.php ENDPATH**/ ?>