<?php $__env->startSection('main_content'); ?>

 <!--Breadcumb area start here-->
 <section class="breadcumb-area jarallax bg-img af">
    <div class="breadcumb">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="content">
                    <h2><?php echo e($contents[0]->title); ?></h2>
                        <?php $__env->startComponent('components.url_link'); ?>
                        <?php $__env->slot('home'); ?>Home
                        <?php $__env->endSlot(); ?>
                        <?php $__env->slot('page_name'); ?><?php echo e($contents[0]->title); ?>

                        <?php $__env->endSlot(); ?>
                    <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Breadcumb area end here-->
   <!--About area start here-->
   <section class="about-area section bg-img mycont-2">
      
    <div class="container">
        <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
        <div class="row">
            <div class="col-md-7 col-sm-12">
                <div class="section-heading2">
                <h2><?php echo e($content->ctitle); ?></h2>
                </div>
                <div class="about-contents">
                <p><?php echo $content->carticle; ?></p>
                
                </div>
            </div>
        
        </div>
        <br><br><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<!--About area end here-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/content.blade.php ENDPATH**/ ?>