<?php $__env->startSection('cms_content'); ?>
   
   <!-- Begin Page Content -->
   <div class="container-fluid">

    <!-- Page Heading -->

   

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php $__env->startComponent('components.cms_components'); ?>
        <?php $__env->slot('title'); ?>Content
        <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
    <a href="<?php echo e(url('cms/content/create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Add New Content</a>
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-12">
        <div class="card shadow mb-4 text-center">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Current Content</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th><b>Title</b></th>
                      <th><b>Menu Link</b></th>
                      <th><b>Last Update</b></th>
                      <th></th>
                    
                    </tr>
                  </thead>
                
                  <tbody>
                 <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                 <tr>
                 <td><?php echo e($item->ctitle); ?></td>
                 <td><?php echo e($menu->find($item->menu_id)->link); ?></td>
                 <td><?php echo e(date('d/m/Y', strtotime($item->updated_at))); ?></td>
                 <td> <a href="<?php echo e(url('cms/content/'. $item->id. '/edit')); ?>" title="Edit Content" class="btn btn-info btn-circle btn-sm">
                  <i class="far fa-edit"></i>
                 </a> <a href="<?php echo e(url('cms/content/'. $item->id)); ?>" title="Delete Content"  class="btn btn-danger btn-circle btn-sm ml-3">
                    <i class="fas fa-trash"></i>
                  </a></td>

                 </tr>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
                  </tbody>
                </table>
              </div>
            </div>
        </div>
          </div>


  </div>
</div>
  <!-- /.container-fluid -->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/cms/content_index.blade.php ENDPATH**/ ?>