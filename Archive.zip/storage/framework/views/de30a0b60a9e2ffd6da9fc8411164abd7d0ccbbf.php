<?php $__env->startSection('main_content'); ?>

  <!--Breadcumb area start here-->
  <section class="breadcumb-area jarallax bg-img af">
    <div class="breadcumb">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="content">
                    <h2><?php echo e($categorie_name[0]->title); ?></h2>
                    <?php $__env->startComponent('components.url_link'); ?>
                    <?php $__env->slot('home'); ?>Home
                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('page_name'); ?><?php echo e($categorie_name[0]->title); ?>

                    <?php $__env->endSlot(); ?>
                <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Breadcumb area end here-->
<!--Products area start here-->
<section class="shop-page section">
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="sibebar">
                   
                    <div class="wighet categories">
                        <h3>categ<span>ories</span></h3>
                        <ul>
                           <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e($categorie->url); ?>"><i class="fa fa-angle-double-right"></i><?php echo e($categorie->title); ?><span><?php echo e($inventory[$counter]->list); ?></span></a></li>
                        <?php
                            $counter++;
                        ?>
                        
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          
                        </ul>
                    </div>
                  
                </div>
            </div>
            <div class="col-sm-9 pd-0">
                <div class="col-sm-12">
                    <div class="filter-area">
                      
                        <div class="list-grid">
                            <ul class="list-inline">
                                <li><a href="#" id="gridview"><i class="fa fa-th"></i></a></li>
                                <li><a href="#" id="listview"><i class="fa fa-list"></i></a></li>
                            </ul>
                        </div>
                        <div class="showpro">
                            
                            <p><span>Showing <?php echo e($products->firstItem()); ?>-<?php echo e($products->lastItem()); ?></span> of <?php echo e($products->total()); ?> Results</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 pd-0">
                   <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="col-sm-4 products">
                   <figure><img height="180" src="<?php echo e(asset('images/'.$product->pimage)); ?>" alt="" /></figure>
                    <div class="contents">
                        <h3><?php echo e($product->ptitle); ?></h3>
                    <p><?php echo e($product->particle); ?></p>
                    <span>$<?php echo e($product->price); ?></span>
                    <?php if(!Cart::get($product->id)): ?>
                    <button data-pid="<?php echo e($product->id); ?>" class="btn1 add-to-cart-btn"><i class="fas fa-cart-plus"></i>  Add To Cart</button>

                    <?php else: ?>
                    <button data-pid="<?php echo e($product->id); ?>" class="btn1 btn-success add-to-cart-btn" disabled="disabled"><i class="fas fa-thumbs-up"></i> Item In Cart</button>

                    <?php endif; ?>
                 <br><br>
                    <a href="<?php echo e(url('shop/'.$product->url.'/' .$product->purl)); ?>" class="btn4"><i class="fas fa-eye"></i> More Details</a>
                    </div>
                </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
               
            </div>
        </div>
    </div>

    <div class="col-sm-12">
        <div class="paginations">
            <ul>
                <li> <?php echo e($products->links()); ?> </li>
             
            </ul>
        </div>
    </div>
</section>
<!--Products area end here-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/products.blade.php ENDPATH**/ ?>