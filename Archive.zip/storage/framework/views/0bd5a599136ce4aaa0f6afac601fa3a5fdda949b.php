<?php $__env->startSection('main_content'); ?>

<!--Slider area start here-->
<section class="slider-area">

        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12 pd-0">
                    <div class="item-content">
                        <div class="item-slider items1 bg-img">
							<div class="slider_section_overlay"></div>
                            <div class="container">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="contents text-center">
                                            <h2 class="wow animated fadeInUp" data-wow-duration="1s">AR15 Commando</h2>
                                            <p class="mr-lu mr-ru wow animated fadeInDown" data-wow-duration="1.5s">Built from a forged upper and lower High End receiver with a standard barrel nut interface and mil-spec controls; The AR15 is made for abuse and high round counts. </p>
                                            <div class="buttons wow animated fadeInUp" data-wow-duration="2s">
                                                <a href="<?php echo e(url('shop/assault-rifles')); ?>" class="btn1">Shop now</a>
                                               
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item-slider items2 bg-img">
						<div class="slider_section_overlay"></div>
                            <div class="container">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="contents text-center">
                                            <h2 class="wow animated fadeInDown" data-wow-duration="1s">M4A1 AR</h2>
                                            <p class="mr-lu mr-ru wow animated fadeInUp" data-wow-duration="1.5s">Built from a forged upper and lower AR-15 receiver with a standard barrel nut interface and mil-spec controls; The MC5 is made for abuse and high round counts. </p>
                                            <div class="buttons wow animated fadeInUp" data-wow-duration="2s">
                                                <a href="<?php echo e(url('shop/assault-rifles')); ?>" class="btn1">Shop now</a>
                                               
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item-slider items3 bg-img">
						<div class="slider_section_overlay"></div>
                            <div class="container">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="contents text-right">
                                            <h2 class="wow animated fadeInRight" data-wow-duration="1s">One Shot, One Kill
                                            </h2>
                                            <p class="mr-lu wow animated fadeInRight" data-wow-duration="1.5s">A Range Of High End Presicion Sniper Rifles Are Available Now</p>
                                            <div class="buttons wow animated fadeInUp" data-wow-duration="2s">
                                                <a href="<?php echo e(url('shop/sniper-rifles')); ?>" class="btn1">Shop now</a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item-slider items4 bg-img">
						<div class="slider_section_overlay"></div>
                            <div class="container">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="contents">
                                            <h2 class="wow animated fadeInLeft" data-wow-duration="1s">M4A1 Marines Edition</h2>
                                            <p class="wow animated fadeInLeft" data-wow-duration="1.5s">Built from a forged upper and lower AR-15 receiver with a standard barrel nut interface and mil-spec controls; The MC5 is made for abuse and high round counts. </p>
                                            <div class="buttons wow animated fadeInUp" data-wow-duration="2s">
                                                <a href="<?php echo e(url('shop/assault-rifles')); ?>" class="btn1">Shop now</a>
                                             
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="item-thumbnail">
                            <a href="#" class="col-sm-3" data-slide-index="0">
                                <div class="items">
                                    <div class="dbox">
                                        <div class="dleft">
                                        <figure><img src="<?php echo e(asset('lib/guns/html/assets/images/sliders/sm-1.jpg')); ?>" alt=""></figure>
                                        </div>
                                        <div class="dright">
                                            <div class="content">
                                                <h3>AR15 Commando</h3>
                                                <p>$7,499.00</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="col-sm-3" data-slide-index="1">
                                <div class="items">
                                    <div class="dbox">
                                        <div class="dleft">
                                            <figure><img src="<?php echo e(asset('lib/guns/html/assets/images/sliders/sm-2.jpg')); ?>" alt=""></figure>
                                        </div>
                                        <div class="dright">
                                            <div class="content">
                                                <h3>M4A1</h3>
                                                <p>$5,000.00</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="col-sm-3" data-slide-index="2">
                                <div class="items">
                                    <div class="dbox">
                                        <div class="dleft">
                                            <figure><img src="<?php echo e(asset('lib/guns/html/assets/images/sliders/sm-3.jpg')); ?>" alt=""></figure>
                                        </div>
                                        <div class="dright">
                                            <div class="content">
                                                <h3>M82 Barrett</h3>
                                                <p>$11,700.00</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="col-sm-3" data-slide-index="3">
                                <div class="items">
                                    <div class="dbox">
                                        <div class="dleft">
                                            <figure><img src="<?php echo e(asset('lib/guns/html/assets/images/sliders/sm-4.jpg')); ?>" alt=""></figure>
                                        </div>
                                        <div class="dright">
                                            <div class="content">
                                                <h3>M4A1 Marine</h3>
                                                <p>$6,200.00</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Slider area end here-->
    <!--About area start here-->
    <section class="about-area section bg-img jarallax">
        <div class="container">
            <div class="row">
                <div class="col-md-7 col-sm-12">
                    <div class="section-heading2">
                        <h2>Who We Are</h2>
                    </div>
                    <div class="about-contents">
                            <p>With state-of-the-art indoor training facilities and full service custom on-line shop, we can accommodate most requests. All modern weapon lovers can appreciate our broad services and real-world, experienced staff. With state-of-the-art indoor training facilities and full service.</p>
                            <blockquote>“This site will revolutionize the purchasing process of silencers, SBRs, AR's and in their class, can accommodate most.”</blockquote>
                            <p>Our goal is to be the single point of service military and veteran Weapons needs. We connect with our audience through our website which averages 4 milllion unique visitors a month</p>
                        <div class="buttons">
                        <a href="<?php echo e(url('about')); ?>" class="btn1">Read More</a>
                            <a href="<?php echo e(url('shop')); ?>" class="btn2">Our Shop</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-5 col-sm-12 ">
                    <div class="about-cata">
                        <div class="cata-list list-t1">
                            <div class="dbox">
                                <div class="dleft">
                                    <div class="content">
                                        <h4>Hunting</h4>
                                       
                                    </div>
                                </div>
                                <div class="dright">
                                    <div class="cate-ico">
                                    <img src="<?php echo e(asset('lib/guns/html/assets/images/icons/01.png')); ?>" alt="" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cata-list list-t2">
                            <div class="dbox">
                                <div class="dleft">
                                    <div class="content">
                                        <h4>Training</h4>
                                    </div>
                                </div>
                                <div class="dright">
                                    <div class="cate-ico">
                                        <img src="<?php echo e(asset('lib/guns/html/assets/images/icons/02.png')); ?>" alt="" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cata-list list-t1">
                            <div class="dbox">
                                <div class="dleft">
                                    <div class="content">
                                        <h4>Shooting Range</h4>
                                       
                                    </div>
                                </div>
                                <div class="dright">
                                    <div class="cate-ico">
                                        <img src="<?php echo e(asset('lib/guns/html/assets/images/icons/03.png')); ?>" alt="" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--About area end here-->
    <!--Banner area start here-->
    <section class="banner-area section bg-img af jarallax">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <div class="banner-con sm-t-center">
                        <h2>New AK47 Carbine</h2>
                        <div class="price">
                            <del>$3,500.00</del>
                            <strong>$4,000.00</strong>
                        </div>
                    <a href="<?php echo e(url('shop')); ?>" class="btn1">Buy Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Banner area end here-->
    <!--Event area start here-->
    <section class="events-area section bg-img jarallax">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="section-heading">
                        <h2>Upcoming Events</h2>
                        <p>specialized facility designed for firearms qualifications, training or practice. Some shooting ranges are operated by military or law enforcement agencies, though the majority of ranges are privately owned and cater to recreational shooters.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="heading1">
                                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne" class="cnc">
                                    <h3>300 Meters Shooting Challenge</h3>
                                    <ul>
                                        <li><i class="far fa-calendar"></i><span>january 25, 2021</span></li>
                                        <li><i class="far fa-clock"></i><span>EST 11.00 to 5.00</span></li>
                                        <li><i class="fas fa-map-marker-alt"></i><span>121, King Street, Melbourne</span></li>
                                    </ul>
                                    <span class="arrows">01</span>
                                </a>
                            </div>
                            <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading1">
                                <div class="panel-body">
                                    <p>In the 300 metre rifle events and the 50 metre rifle and pistol events, all participants of a main competition must compete at the same time. If the range capacity is not enough for this, an elimination round is conducted the day before the main competition. From this round, only so many shooters advance as the range capacity can allow. The program of the elimination round is the same as that of the match or qualification round.</p>
                                   
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="heading2">
                                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse2" aria-expanded="true" aria-controls="collapseOne" class="cnc btncnc">
                                    <h3>50 Meters Pistol Tournament</h3>
                                    <ul>
                                        <li><i class="far fa-calendar"></i><span>april 19, 2021</span></li>
                                        <li><i class="far fa-clock"></i><span>EST 11.00 to 5.00</span></li>
                                        <li><i class="fas fa-map-marker-alt"></i><span>121, King Street, Melbourne</span></li>
                                    </ul>
                                    <span class="arrows">02</span>
                                </a>
                            </div>
                            <div id="collapse2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading2">
                                <div class="panel-body">
                                    <p>The 50 meter pistol, formerly and unofficially still often called free pistol, is one of the ISSF shooting events. It provides the purest precision shooting among the pistol events, and is one of the oldest shooting disciplines, dating back to the 19th century and only having seen marginal rule changes since 1936. Most of the changes concern distance (30m, 50m, 50 Yards), caliber (.22 .22lr .44CF), type of pistol (revolver only, revolver or pistol, any pistol), time allowed (16 hours, 6 hours, 3 hours, 2 hours, 1 hour and 15 minutes), and most recently, format of the finals (carry over scores, start from zero, number of shots fired in the finals). The target of this event has not changed since 1900, and the 50m distance has remained the standard since 1912. Competitors have been using the small-bore, rim-fire cartridge since 1908. The sport traced back to the beginning of indoor Flobert pistol parlor shooting in Europe during the 1870s, which in turn traced back to 18th century pistol dueling.</p>
                                   
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="heading3">
                                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse3" aria-expanded="true" aria-controls="collapseOne" class="cnc btncnc">
                                    <h3>10 Meters Running Target</h3>
                                    <ul>
                                        <li><i class="far fa-calendar"></i><span>may 5, 2021</span></li>
                                        <li><i class="far fa-clock"></i><span>EST 11.00 to 5.00</span></li>
                                        <li><i class="fas fa-map-marker-alt"></i><span>121, King Street, Melbourne</span></li>
                                    </ul>
                                    <span class="arrows">03</span>
                                </a>
                            </div>
                            <div id="collapse3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3">
                                <div class="panel-body">
                                    <p>10 meter running target is one of the ISSF shooting events, shot with an airgun at a target that moves sideways. The target is pulled across a two meter wide aisle at the range of 10 metres from the firing point. The target is pulled at either of two speeds, slow or fast, where it is visible for 5 or 2.5 seconds, respectively.</p>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Event area End here-->
    <!--Videos area start here-->
    <section class="banner-area2 bg-img jarallax af">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="videos-area text-center">
                        <div class="video-popups">
                            <a href="https://www.youtube.com/watch?v=MH4_iTz-BmE" class="video-play-icon"><i class="fas fa-play"></i></a>
                        </div>
                        <div class="section-heading mr-0">
                            <h2 class="mr-0">The New AR15 Commando Edition</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="lg-text">
            <h1>Coming Soon</h1>
        </div>
    </section>
    <!--Videos area end here-->
    <!--Products area start here-->

   
    <section class="products-area section bg-img jarallax">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="section-heading">
                        <h2>Our Products</h2>
                        <p>All modern weaponts can appreciate our broad services akshay handge pharetra, eratd fermentum feugiat, gun are best velit mauris aks egestasut aliquam.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 pro-ctg">
                   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                   <?php if($key%2==0): ?>

                   <div class="col-md-3 col-sm-6 pd-0">
                   <a href="<?php echo e(url('shop/'.$categorie->url)); ?>"><div class="catagories-lists">
                        <div class="contents">
                        <figure><img src="<?php echo e(asset('lib/guns/html/assets/images/products/'.$categorie->icon)); ?>" alt="" /></figure>
                        <h3><?php echo e($categorie->title); ?></h3>
                        </div>
                    </div>
                </a>
                </div>
                       
                   <?php else: ?>
                       
                   <div class="col-md-3 col-sm-6 pd-0">
                    <a href="<?php echo e(url('shop/'.$categorie->url)); ?>"><div class="catagories-lists nd">
                        <div class="contents">
                            <figure><img src="<?php echo e(asset('lib/guns/html/assets/images/products/'.$categorie->icon)); ?>" alt="" /></figure>
                            <h3><?php echo e($categorie->title); ?></h3>
                        </div>
                    </div>
                </a>
                </div>

                   <?php endif; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
        
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 pd-0">
                    <div class="pro-sliders">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-12">
                            <div class="products">
                            <figure><img height="200" src="<?php echo e(asset('images/'.$product->pimage)); ?> "alt="" /></figure>
                                <div class="contents">
                                <h3><?php echo e($product->ptitle); ?></h3>
                                <span>$<?php echo e($product->price); ?></span>
                               
                                <a href="<?php echo e(url('shop/'.$product->url.'/'.$product->purl)); ?>" class="btn4">More Details</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
                <div class="col-md-12 col-sm-12">
                    <div class="load-btn text-center mr-t80">
                    <a href="<?php echo e(url('shop')); ?>" class="btn1">Enter Shop</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Products area end here-->
 
    <!--Gallery area start here-->
    <section class="gallery-area section2 bg-img jarallax">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="section-heading">
                        <h2>Photo Gallery</h2>
                    <p>All Tactical Gear And Weapons Shown Are Sold On Our <a href="<?php echo e(url('shop')); ?>" class="text-primary">Shop</a></p>
                    </div>
                </div>
                <div class="gallery col-sm-12 pd-0">
                    <div class="col-md-4 col-sm-4 col-xs-12 pd-0">
                        <div class="col-sm-12 mr-b30">
                            <div class="gimg">
                                <figure>
                                <a href="<?php echo e(url('lib/guns/html/assets/images/gallery/1.jpg')); ?>">
                                <img src="<?php echo e(asset('lib/guns/html/assets/images/gallery/1.jpg')); ?>" alt="" />
                                        <div class="con-pop">
                                            <span><i class="fas fa-search"></i></span>
                                        </div>
                                    </a>
                                    <div class="content">
                                        <h3>M4 + Mpact Gloves</h3>
                                        <p>Colt's Primary Assault Rifle, Held By State Of The Art G9-Mpact Tactical Gloves.</p>
                                    </div>
                                </figure>
                            </div>
                        </div>
                        <div class="col-sm-12 mr-b30">
                            <div class="gimg">
                                <figure>
                                    <a href="<?php echo e(url('lib/guns/html/assets/images/gallery/4.jpg')); ?>">
                                        <img src="<?php echo e(asset('lib/guns/html/assets/images/gallery/4.jpg')); ?>" alt="" />
                                        <div class="con-pop">
                                            <span><i class="fas fa-search"></i></span>
                                        </div>
                                    </a>
                                    <div class="content">
                                        <h3>Full Tactical Gear</h3>
                                        <p>We Supply Private And Federal Tactical Squads.</p>
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-12 pd-0">
                        <div class="col-sm-12 mr-b30">
                            <div class="gimg">
                                <figure>
                                    <a href="<?php echo e(url('lib/guns/html/assets/images/gallery/2.jpg')); ?>">
                                        <img height="615" width="350" src="<?php echo e(asset('lib/guns/html/assets/images/gallery/2.jpg')); ?>" alt="" />
                                        <div class="con-pop">
                                            <span><i class="fas fa-search"></i></span>
                                        </div>
                                    </a>
                                    <div class="content">
                                        <h3>M4A1 LightWeight</h3>
                                        <p>Fully Modified M4A1, Rebuilt From Carbon And Camo Finish For A Light, Heavy-Duty, Assault Rifle.</p>
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-12 pd-0">
                        <div class="col-sm-12 mr-b30">
                            <div class="gimg">
                                <figure>
                                    <a href="<?php echo e(url('lib/guns/html/assets/images/gallery/3.jpg')); ?>">
                                        <img src="<?php echo e(asset('lib/guns/html/assets/images/gallery/3.jpg')); ?>" alt="" />
                                        <div class="con-pop">
                                            <span><i class="fas fa-search"></i></span>
                                        </div>
                                    </a>
                                    <div class="content">
                                        <h3>Colt 19 Desert Edition</h3>
                                        <p>Fitted With MIRA Red Dot, Tactical Flashlight, And A Prestine Snake Skin Finish.
                                        </p>
                                    </div>
                                </figure>
                            </div>
                        </div>
                        <div class="col-sm-12 mr-b30">
                            <div class="gimg">
                                <figure>
                                    <a href="<?php echo e(url('lib/guns/html/assets/images/gallery/6.jpg')); ?>">
                                        <img src="<?php echo e(asset('lib/guns/html/assets/images/gallery/6.jpg')); ?>" alt="" />
                                        <div class="con-pop">
                                            <span><i class="fas fa-search"></i></span>
                                        </div>
                                    </a>
                                    <div class="content">
                                        <h3>AR15 Hellfire</h3>
                                        <p>M4A1 On Steroids.</p>
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8 col-sm-8 col-xs-12 pd-0">
                        <div class="col-sm-12 mr-b30  lst_div_box_galery hidden-xs">
                            <div class="gimg">
                                <figure>
                                    <a href="<?php echo e(url('lib/guns/html/assets/images/gallery/5.jpg')); ?>">
                                        <img width="770" height="290" src="<?php echo e(asset('lib/guns/html/assets/images/gallery/5.jpg')); ?>" alt="" />
                                        <div class="con-pop">
                                            <span><i class="fas fa-search"></i></span>
                                        </div>
                                    </a>
                                    <div class="content">
                                        <h3>AK47</h3>
                                        <p>The All Known, All Loved, 0 Jams Automata Kalashnikova Assault Rifle.</p>
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Gallery area end here-->
    <!--Trainning area Start here-->
    <section class="training-area section bg-img jarallax af">
        <div class="container">
            <div class="row">
                
                <div class="col-md-6 col-sm-12">
                    <div class="training-con pd-t60">
                        <h2>Weapons Training</h2>
                        <p>With state-of-the-art indoor/outdoor training facilities and full service custom on-line shop, we can accommodate most requests.</p>
                        <h1>050-7725079</h1>
                        <p>Firing range walls are usually constructed of poured concrete, precast concrete, or masonry block. The walls must be impenetrable and provide adequate ballistic protection from stray bullets and back splatter. Floors are constructed from dense reinforced concrete with a smooth surface finish. Floors are usually slanted slightly from uprange (shooting lanes) toward the bullet trap downrange to allow for better maintenance and cleaning.</p>
                        <ul>
                            <li><i class="fas fa-long-arrow-alt-right"></i>Hand Gun Trainning Full Pack</li>
                            <li><i class="fas fa-long-arrow-alt-right"></i>Machine Gun M4A1 AK47 Full Pack </li>
                            <li><i class="fas fa-long-arrow-alt-right"></i>Custom Shooting Range For Trainning</li>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Trainning area End here-->
    <!--Price area Start here-->
    <section class="price-area section bg-img jarallax">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="section-heading">
                        <h2>Trainning Pricing</h2>
                        <p>All modern weaponts can appreciate our broad services akshay handge pharetra, eratd fermentum feugiat, gun are best velit mauris aks egestasut aliquam.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="col-sm-4 pd-0">
                        <div class="price-lists">
                            <div class="phead">
                                <ul class="rate">
                                    <li><i class="fas fa-star"></i></li>
                                </ul>
                                <h3>Hand Guns</h3>
                                <div class="prices">
                                    <strong><i class="fas fa-dollar-sign"></i>49</strong>
                                    <span>/per mo</span>
                                </div>
                            </div>
                            <div class="pbody">
                                <ul>
                                    <li><span>1911 Berreta</span></li>
                                    <li><span>Colt 17</span></li>
                                    <li><span>44 Magnum Revolver</span></li>
                                    <li><span>Desert Eagle</span></li>
                                </ul>
                                <a href="<?php echo e(url('/contact')); ?>" class="btn4">Contact Us!</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 pd-0">
                        <div class="price-lists middel">
                            <div class="phead">
                                <ul class="rate">
                                    <li><i class="fas fa-star"></i></li>
                                    <li><i class="fas fa-star"></i></li>
                                    <li><i class="fas fa-star"></i></li>
                                </ul>
                                <h3>Marksman Training</h3>
                                <div class="prices">
                                    <strong><i class="fas fa-dollar-sign"></i>79</strong>
                                    <span>/per mo</span>
                                </div>
                            </div>
                            <div class="pbody">
                                <ul>
                                    <li><span>M82 Barrett</span></li>
                                    <li><span>M200 Intervention</span></li>
                                    <li><span>M24 Bolt Action</span></li>
                                    <li><span>Kar98 Carbine</span></li>
                                </ul>
                            <a href="<?php echo e(url('/contact')); ?>" class="btn4">Contact Us!</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 pd-0">
                        <div class="price-lists">
                            <div class="phead">
                                <ul class="rate">
                                    <li><i class="fas fa-star"></i></li>
                                    <li><i class="fas fa-star"></i></li>
                                </ul>
                                <h3>Assault Rifles</h3>
                                <div class="prices">
                                    <strong><i class="fas fa-dollar-sign"></i>99</strong>
                                    <span>/per mo</span>
                                </div>
                            </div>
                            <div class="pbody">
                                <ul>
                                    <li><span>M4A1 Assault</span></li>
                                    <li><span>AK 47</span></li>
                                    <li><span>Scar-L</span></li>
                                    <li><span>AR15 Commando</span></li>
                                </ul>
                                <a href="<?php echo e(url('/contact')); ?>" class="btn4">Contact Us!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Price area End here-->
    <!--Banner area start here-->
    <section class="banner-area3 section af bg-img jarallax">
        <div class="container">
            <div class="row">
                <div class="col-md-7 col-sm-12 col-md-offset-5">
                    <div class="content">
                        <div class="con">
                            <h2>THREAT-MANAGEMENT <br>EXPERTS</h2>
                            <p>Our facilities in Tilden, TX offer great ranges and accommns for anyone looking to attend one of our hunts or training ses. Tilden has a 1000 yard range with steel every 100 yards as well a unknown distance steel throughout. For aerial opens we have vehicle interdiction.</p>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Banner area end here-->
   
    <!--Partner area start here-->
    <section class="partner-area section bg-img jarallax">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="section-heading">
                        <h2>Our Trusted Partners</h2>
                        <p>All Of Our Events Are Sponsored By Our Buisness Partners As Listed Below.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="partner-list">
                        <ul>
                            <li>
                            <a href="http://www.greenvilleyouthfootball.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/1.png')); ?>" alt="" /></a>
                            </li>
                            <li>
                            <a href="https://jeans.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/2.png')); ?>" alt="" /></a>
                            </li>
                            <li>
                            <a href="https://www.dressmakerschoice.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/3.png')); ?>" alt="" /></a>
                            </li>
                            <li>
                            <a href="http://www.medley.co.uk/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/4.png')); ?>" alt="" /></a>
                            </li>
                            <li>
                             <a href="https://azpbs.org/tv/arizonacollection/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/5.png')); ?>" alt="" /></a>
                            </li>
                            <li>
                             <a href="https://www.woodn.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/6.png')); ?>" alt="" /></a>
                            </li>
                            <li>
                             <a href="https://www.advisorclient.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/7.png')); ?>" alt="" /></a>
                            </li>
                            <li>
                            <a href="https://folioclient.com/fc-index.jsp"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/8.png')); ?>" alt="" /></a>
                            </li>
                            <li>
                             <a href="https://goals.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/9.png')); ?>"alt="" /></a>
                            </li>
                            <li>
                             <a href="http://olympiaoceancarriers.com/"><img src="<?php echo e(asset('lib/guns/html/assets/images/client/10.png')); ?>" alt="" /></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Partner area End here-->
   
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/GUNS/resources/views/home.blade.php ENDPATH**/ ?>