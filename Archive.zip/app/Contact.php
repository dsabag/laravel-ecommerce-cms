<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB,Session;

class Contact extends Model
{
static public function saveNew($request){
$contact = new self();
$contact->user_id = Session::get('user_id');
$contact->name = $request['name'];
$contact->cemail = $request['email'];
$contact->subject = $request['subject'];
$contact->message = $request['message'];
$contact->save();
Session::flash('success','Your Message Was Sent');

}


static public function getAll(){


    return DB::table('contacts as c')
    ->join('users as u','u.id','=','c.user_id')
    ->select('u.email','c.*')
    ->orderBy('c.created_at','desc')
    ->paginate(3);
}
    

}
