<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\ProductRequest;
use Session,Exception,DB;
use App\Product;
use App\Categorie;


class ProductsController extends MainController
{
   
    public function index()
    {
        self::$dtv['product_category'] = Product::getAllWithCatUrl();
       return view('cms.products_index',self::$dtv);
    }
    

   
    public function create()
    {
        self::$dtv['categories'] = Categorie::all();
        return view('cms.products_create',self::$dtv);
    }

  
    public function store(ProductRequest $request)
    {
        Product::saveNew($request);
        return redirect('cms/products');
    }

   
    public function show($id)
    {
        
        self::$dtv['item_id'] = $id;
        return view('cms.product_delete',self::$dtv);
    }

 
    public function edit($id)
    {
     
        self::$dtv['categories'] = Categorie::all();
        self::$dtv['item'] = Product::find($id);
        return view('cms.products_edit',self::$dtv);
    }

   
    public function update(ProductRequest $request, $id)
    {
        
    Product::updateItem($request,$id);
    return redirect('cms/products');


    }

   
    public function destroy($id)
    {
       try{
        Product::destroy($id);
        Session::flash('success','The Product Has Been Deleted');
       }catch(Exception $ex){

       };
       return redirect('cms/products');
    }
}
