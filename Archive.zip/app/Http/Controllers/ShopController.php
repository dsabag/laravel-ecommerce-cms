<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Categorie;
use App\Product;
use App\Order;
use Cart, Session;

class ShopController extends MainController
{
    public function shop(){
        
        self::$dtv['page_title'].='Categories';  
        
        return view('shop',self::$dtv);
    
    }

     public function products($curl){
        
     
        self::$dtv['counter'] =0;
        self::$dtv['inventory'] = Product::inventory();
        self::$dtv['categorie_name'] = Categorie::getCategorieName($curl);    
        $products = Product::getProducts($curl);
        if(!$products->count()) abort(404);
        self::$dtv['products']= $products;
        self::$dtv['page_title'] .= $products[0]->title;
        return view('products',self::$dtv);

    }

    public function productDetails($curl, $purl){
       
        self::$dtv['categorie_name'] = Categorie::getCategorieName($curl);
        $product = Product::where('purl', '=' , $purl)->first();
        if(! $product) abort(404);
        self::$dtv['product']= $product;
        self::$dtv['page_title'].= $product->ptitle;
        $highlights = ucwords($product->highlights);
        $highlights = explode('|',$highlights);
        $highlights = str_replace("<p>"," ",$highlights);
        self::$dtv['highlights']= $highlights;
        
        return view('details', self::$dtv);


    }

    public function addToCart(Request $request){

    Product::addToCart($request['products_id']);

}


    public function cart(Request $request){

        if(!empty($request['removeItem'])) $this->removeItem($request['removeItem']);
        self::$dtv['page_title'].= 'Checkout';
      
        $cart=Cart::getContent()->toArray();
        sort($cart);
        self::$dtv['cart'] = $cart;
        return view ('cart',self::$dtv);

    }

    public function removeItem(Request $request){

    
    Cart::remove($request['item_id']);

    }
    

    public function clearCart(){

    Cart::clear();

    }

    public function updateCart(Request $request){

    Product::updateCart($request);
    }

    public function checkout(){
    if(Cart::isEmpty()) return redirect('shop/cart');
    if(!Session::has('user_id')) return redirect('user/signin?backto=shop/cart');

    Order::saveNew();
    return redirect('shop');
    }
}
