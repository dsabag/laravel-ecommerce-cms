<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Categorie;
use App\product;
use App\Menu;
use Cart,Session;

class MainController extends Controller
{
    public static $dtv;

    public function __construct(){


        self::$dtv = [
            'menu'=> Menu::all(),
            'page_title'=>'S.O.A.G | ',           
            'categories' => Categorie::all(),
            'products' => Product::getAllWithCatUrl(),
           

        ];

    }

}
