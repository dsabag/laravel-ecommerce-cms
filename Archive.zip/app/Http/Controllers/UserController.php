<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\SignupRequest;
use App\Http\Requests\SigninRequest;
use App\User;
use Session;


class UserController extends MainController
{

    public function __construct(){
    parent::__construct();
    $this->middleware('userauth',['except'=>['logout','profile']]);

//added profile for profile page
    }

    public function signin(){
        self::$dtv['page_title'].='Sign In';
    return view('signin', self::$dtv);
}
    public function signup(){
        self::$dtv['page_title'].='Sign Up';
   
    return view('signup', self::$dtv);
}
    public function postSignup(SignupRequest $request){

        User::saveNew($request);
        return redirect('');
}

public function postSignin(SigninRequest $request){

if(User::verify($request['email'],$request['password'])){

$to = !empty($request['backto']) ? $request['backto']:'';

return redirect($to);
}
else{

    self::$dtv['page_title'].='Sign In';
    self::$dtv['verify_error'] ='Wrong Email And Password Combination';
    return view('signin', self::$dtv);
}

}

public function logout(){

Session::forget([
    'user_id',
    'user_name',
    'is_admin',
    
]);

return redirect('user/signin');
}

}
