<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Order;
use App\Contact;
use Session;


class CmsController extends MainController
{
    public function dashboard(){

   
   self::$dtv['contacts'] = Contact::all()->count();
    self::$dtv['users'] = User::all();
    self::$dtv['orders'] = Order::getAll();
    return view('cms.cms_dashboard',self::$dtv);
        
    }
    public function orders(){

    self::$dtv['orders'] = Order::getAll();
    return view('cms.orders',self::$dtv);

    }
    public function contacts(){

    self::$dtv['contacts'] = Contact::getAll();
    return view('cms.contacts',self::$dtv);

    }



}
