<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\ContactRequest;
use App\Content;
use App\Contact;
use Cart,Session;

class PagesController extends MainController
{
    public function home(){
        self::$dtv['page_title'].='Home Page';
       
    return view('home',self::$dtv);
    }

    public function about(){
        self::$dtv['page_title'].='About Us';
        
       
        return view('about', self::$dtv);
    }
    
    public function contact(){
        self::$dtv['page_title'].='Contact';
        return view('contact', self::$dtv);
    }
    public function postSignup(SignupRequest $request){

        User::saveNew($request);
        return redirect('');
}
    public function postContact(ContactRequest $request){

        if(Session::has('user_id')){
            Contact::saveNew($request);
            return redirect('');
            
        }else{
            Session::flash('error','You Must Sign In First');
            return redirect('user/signin');

        }
        
        
}


    public function gallery(){
        self::$dtv['page_title'].='Gallery';
       
       
        return view('gallery', self::$dtv);
    }

public function content($menu_url){

    self::$dtv['contents']=Content::getAll($menu_url);
    if(! self::$dtv['contents']->count()) abort(404);
    self::$dtv['page_title'].= self::$dtv['contents'][0]->title;

    return view('content',self::$dtv);





}


}
