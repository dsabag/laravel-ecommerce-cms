<?php

namespace App\Http\Requests;

use Illuminate\Http\Request;
use Illuminate\Foundation\Http\FormRequest;

class ProductRequest extends FormRequest
{
   
    public function authorize()
    {
        return true;
    }

  
    public function rules(Request $request)
    {

        $item_id = !empty($request['item_id']) ? ',' . $request['item_id'] : '';
        return [
            'category' => 'required',
            'title' => 'required|min:2|max:255',
            'url' => 'required|min:2|max:255|regex:/^[a-z\d-]+$/|unique:products,purl' . $item_id,
            'price' => 'required|numeric',
            'about' => 'required|min:2',
            'image' => 'image',
            'image2' => 'image',
            'image3' => 'image',
            'image4' => 'image',
            'image5' => 'image',

        ];
    }
}
