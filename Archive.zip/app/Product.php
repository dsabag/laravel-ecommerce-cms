<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB, Cart, Session,FileManager;

class Product extends Model
{
    static public function getProducts($curl){

        return DB::table('products as p')
         ->join('categories as c','c.id','p.categorie_id')
         ->select('p.*', 'c.title','c.url')
         ->where('c.url','=', $curl)
         ->orderBy('p.price')
         ->paginate(3);
        }
        

        static public function inventory(){

         return DB::table('products as p')
         ->join('categories as c','c.id','p.categorie_id')
         ->select(array(DB::raw('COUNT(p.categorie_id) as list','c.title','c.url')))
         ->groupBy('p.categorie_id')
         ->get();
        }

        static public function getProductCategorie($pid){

            return DB::table('products as p')
            ->join('categories as c','c.id','p.categorie_id')
            ->select('p.*','c.*')
            ->where('p.id','=', $pid)
           ->first();

        }

        static public function getAllWithCatUrl(){

            return DB::table('products as p')
            ->join('categories as c','c.id','p.categorie_id')
            ->select('p.*','c.url')
           ->paginate(5);


        }


        static public function addToCart($pid){
        if(is_numeric($pid) && $product = self::find($pid)){
         
            if(! Cart::get($pid)){
                
                Cart::add($pid, $product->ptitle,$product->price,1,['image'=> $product->pimage,'categorie'=>self::getProductCategorie($pid)->url,'url'=>self::getProductCategorie($pid)->purl]);
               
                Session::flash('success',$product->ptitle . ' Added To Shopping Cart' );
                
            }
    
        }
        
    }

    static public function updateCart($request){

        if(!empty($request['pid']) && is_numeric($request['pid']) ){

         if($request['op'] == 'plus'){

                 Cart::update($request['pid'], ['quantity'=>1]);

            }elseif($request['op']=='minus'){

                Cart::update($request['pid'], ['quantity'=>-1]);
                 }

        }

    }

    static public function saveNew($request){
        $product = new self();
        $product->categorie_id = $request['category'];
        $product->ptitle = $request['title'];
        $product->particle = $request['about'];
        $product->description = $request['description'];
        $product->specifications = $request['specs'];
        $product->highlights = $request['highlights'];
        $product->pimage = FileManager::loadImage($request,'image');
        $product->pimage2 = FileManager::loadImage($request,'image2');
        $product->pimage3 = FileManager::loadImage($request,'image3');
        $product->pimage4 = FileManager::loadImage($request,'image4');
        $product->pimage5 = FileManager::loadImage($request,'image5');
        $product->price = $request['price'];
        $product->purl = $request['url'];
        $product->save();
        Session::flash('success',"Product Saved");

    }

    static public function updateItem($request,$id){
        $product = self::find($id);
        $product->categorie_id = $request['category'];
        $product->ptitle = $request['title'];
        $product->particle = $request['about'];
        $product->description = $request['description'];
        $product->specifications = $request['specs'];
        $product->highlights = $request['highlights'];
        $product->pimage = FileManager::loadImage($request,'image',$product->pimage);
        $product->pimage2 = FileManager::loadImage($request,'image2',$product->pimage2);
        $product->pimage3 = FileManager::loadImage($request,'image3',$product->pimage3);
        $product->pimage4 = FileManager::loadImage($request,'image4',$product->pimage4);
        $product->pimage5 = FileManager::loadImage($request,'image5',$product->pimage5);
        $product->price = $request['price'];
        $product->purl = $request['url'];
        $product->save();
        Session::flash('success',"Product Updated");

    }
    
}
