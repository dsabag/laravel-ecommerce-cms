<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Str,Image;

class FileManagerServiceProvider extends ServiceProvider
{
    const DEFAULT_FILE_NAME = 'default.png';
    const ALLOWED_IMAGES =['jpg','jpeg','png','gif','bmp'];

    public function register()
    {
        //
    }

    public function boot()
    {
        //
    }

    static public function loadImage($request,$name,$default_name = false){

    $image_name = $default_name ? $default_name :self::DEFAULT_FILE_NAME;

    if($request->hasFile($name) && $request->file($name)->isValid()){
    $file = $request->file($name);
        if(in_array(strtolower($file->getClientOriginalExtension()) , self::ALLOWED_IMAGES)){

          $image_name = self::generateRandomFileName($file->getClientOriginalName());   
          $request->file($name)->move(public_path().'/images',$image_name);
          $img = Image::make(public_path().'/images/'.$image_name);
          $img->resize(null,250, function ($constraint) {
            $constraint->aspectRatio();
          });
          $img->save();
         
        }
      }
      
        return $image_name;
      
    }
    

    static private function generateRandomFileName($original_name){

        return date('Y.m.d.H.i.s').'-'. Str::random(5).' -'.$original_name; 

    }
}
