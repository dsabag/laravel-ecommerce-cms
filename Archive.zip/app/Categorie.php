<?php

namespace App;
use DB,FileManager,Session;

use Illuminate\Database\Eloquent\Model;


class Categorie extends Model
{
    
   
    static public function getCategorieName($curl){

        return DB::table('categories as c')
        ->join('products as p','c.id','p.categorie_id')
         ->select('p.*', 'c.title','c.url')
         ->where('c.url','=', $curl)
         ->get();
        }

       static public function saveNew($request){
        $category = new self();
        $category->title = $request['title'];
        $category->image = FileManager::loadImage($request,'image');
        $category->url = $request['url'];
        $category->save();

        Session::flash('success','Category Saved');

       }

       static public function updateItem($request,$id){

        $category = self::find($id);
        $category->title = $request['title'];
        $category->image = FileManager::loadImage($request,'image', $category->image);
        $category->url = $request['url'];
        $category->save();

        Session::flash('success','Category Updated');

       }




}
