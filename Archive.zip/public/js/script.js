String.prototype.permalink = function() {
  return this.toString()
    .trim()
    .toLowerCase()
    .replace(/\s/g, "-");
};

$(".add-to-cart-btn").on("click", function() {
  var pid = $(this).data("pid");
  $.ajax({
    url: BASE_URL + "shop/add-to-cart",
    type: "GET",
    dataType: "html",
    data: {
      products_id: pid
    },
    success: function(res) {
      window.location.reload();
    }
  });
});

$(".clear-cart-btn").on("click", function(e) {
  e.preventDefault();
  $.ajax({
    url: BASE_URL + "shop/clear-cart",
    type: "GET",
    dataType: "html",
    success: function(res) {
      window.location.reload();
    }
  });
});

$(".remove-from-cart-btn").on("click", function(e) {
  e.preventDefault();
  var pid = $(this).data("pid");
  $.ajax({
    url: BASE_URL + "shop/remove-item",
    type: "GET",
    dataType: "html",
    data: {
      item_id: pid
    },
    success: function(res) {
      window.location.reload();
    }
  });
});

$(".update-cart-btn").on("click", function() {
  $.ajax({
    url: BASE_URL + "shop/update-cart",
    type: "GET",
    dataType: "html",
    data: {
      pid: $(this).data("pid"),
      op: $(this).data("op")
    },
    success: function(res) {
      window.location.reload();
    }
  });
});

$(".origin").on("focusout", function() {
  $(".target").val(
    $(this)
      .val()
      .permalink()
  );
});

$(".article").summernote({
  height: 150
});

$(".image-upload").change(function() {
  var fileName = $(this)
    .val()
    .split("\\")
    .pop();
  $(this)
    .next()
    .html(fileName);
});
